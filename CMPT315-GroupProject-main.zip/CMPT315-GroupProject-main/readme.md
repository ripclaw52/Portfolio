# Setup

If on MacOS, just install docker

If on Windows, install WSL2 (optional, but highly recommended), then docker

`git clone` the repo into wsl (or on mac, just anywhere)

Make sure docker is running

run `docker-compose up` in the cloned folder, it *should* magically set 
everything up for you

once text stops scrolling go to http://localhost:3000
I mean you can go there before its done, but you'll just get errors
until its done 

# Why docker

- Consistency across multiple machines

- If you want to update, all you have to do is `git pull` then `docker compose up`
    - Don't have to worry about new db version, or python version, or node versions

- We can push config into the repo so everyone is using the same environment

- The Ops guy (Sam) will make sure it works, if not bug him right away

# FYI

Always open up WSL2 before you open docker, things just seem to work better
this way.

If you run into problems try   
    `docker compose down`, then   
    `docker compose up` again.

You can have the docker composition run in the background with the `-d` flag.  
    `docker compose up -d`

You can get inside of a running container with the command  
    `docker exec -it CONTAINER_NAME ash`  
or   
    `docker exec -it CONTAINER_NAME bash`

You can get the container name with   
    `docker ps`

You can get logs from the Docker Desktop GUI
as well as with  
    `docker logs CONTAINER_NAME`  
you can put `-f` at the end of the log view command to follow.

In order to login to django, you'll need to create a superuser
Inside the backend container run:   
    `python manage.py createsuperuser --email admin@example.com --username admin`

If the backend container is not working and is printing an error regarding 
a missing packaged (eg ModuleNotFoundError: No module named 'rest_framework'):  
    `docker compose down`  
    `docker compose build --no-cache`  
    `docker compose up -d`  
This occurs when a new package is added. The issue is that docker caches the old
python packages, and doesn't update them with the new package. Building without
the cache gets around this.

# Mock data

We have some mock data located in `backend/backendDjango/api/fixtures`, they are
simple json files. To load the data into your local database do the following:
`docker exec -it BACKEND_CONTAINER_NAME ash`
`./manage.py loaddata JSON_FILE`

Docs: https://docs.djangoproject.com/en/4.1/howto/initial-data/

See the existing JSON files on how to expand the data.

# VsCode Python intellisense stuff

vscode won't know what libs we're using since there is no venv

Run the `setup_venv.sh` or `setup_venv.bat` script to set this up

It is not used for running the web server, this is just for vscode

# Folders

backend:    django backend
frontend:   javascript/typescript react frontend
database:   your local database, this is disposable
docker:     build files for creating docker images for this project
