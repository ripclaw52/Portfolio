exit_code=1

# probe db to ensure its ready for connections
# if its not, just wait 10 seconds and try again
until [[ $exit_code -eq 0 ]];
do 
    python probe_db.py 
    exit_code=$?
    if  [[ $exit_code -ne 0 ]];
    then
        echo 'Unable to connect to db, waiting 3 seconds'
        sleep 3
    fi
done
echo 'Connected to db'

python manage.py migrate
python manage.py runserver 0.0.0.0:3000