from django.shortcuts import render
from .models import Customer, CustomerPhoneNumber, Car, CarType
from rest_framework import viewsets
from rest_framework.response import Response
from .serializers import Car, CarSerializer, CarType, CarTypeSerializer, CustomerSerializer, CustomerPhoneNumberSerializer, Employee, EmployeeSerializer, EmployeePhoneNumber, EmployeePhoneNumberSerializer, Branch, BranchSerializer, BranchPhoneNumber, BranchPhoneNumberSerializer, Rental, RentalSerializer
# Create your views here.

# Ref:
#   https://www.django-rest-framework.org/api-guide/viewsets/

    # def retrieve(self, request, pk=None):
    #     queryset = User.objects.all()
    #     user = get_object_or_404(queryset, pk=pk)
    #     serializer = UserSerializer(user)
    #     return Response(serializer.data)

class CustomerView(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

class CustomerPhoneView(viewsets.ModelViewSet):
    queryset = CustomerPhoneNumber.objects.all()
    serializer_class = CustomerPhoneNumberSerializer
    
class EmployeeView(viewsets.ModelViewSet):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer

class EmployeePhoneView(viewsets.ModelViewSet):
    queryset = EmployeePhoneNumber.objects.all()
    serializer_class = EmployeePhoneNumberSerializer

class BranchView(viewsets.ModelViewSet):
    queryset = Branch.objects.all()
    serializer_class = BranchSerializer

class BranchPhoneView(viewsets.ModelViewSet):
    queryset = BranchPhoneNumber.objects.all()
    serializer_class = BranchPhoneNumberSerializer

class RentalView(viewsets.ModelViewSet):
    queryset = Rental.objects.all()
    serializer_class = RentalSerializer

class CarView(viewsets.ModelViewSet):
    queryset = Car.objects.all()
    serializer_class = CarSerializer
    
class CarTypeView(viewsets.ModelViewSet):
    queryset = CarType.objects.all()
    serializer_class = CarTypeSerializer
