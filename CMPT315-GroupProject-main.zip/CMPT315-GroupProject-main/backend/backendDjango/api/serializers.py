from wsgiref import validate
from rest_framework import serializers
from .models import BranchPhoneNumber, EmployeePhoneNumber, Car, CarType,Customer, CustomerPhoneNumber, Branch, Employee, Rental


class CustomerSerializer (serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = ('CustomerID', 'FirstName', 'LastName', 'DriversLicense', 'Email', 
        'DOB', 'GoldMember', 'Province', 'City', 'PostalCode', 
        'StreetNumber', 'StreetName', 'UnitNumber')
        read_only_fields = ['CustomerID']



class CustomerPhoneNumberSerializer (serializers.ModelSerializer):
    class Meta:
        model = CustomerPhoneNumber
        fields = ('CustomerID', 'PhoneNumber')
        read_only_fields = ['CustomerID']

class BranchPhoneNumberSerializer (serializers.ModelSerializer):
    class Meta:
        model = BranchPhoneNumber
        fields = ['BranchID', 'PhoneNumber']
        read_only_fields = ['BranchID']

class EmployeePhoneNumberSerializer (serializers.ModelSerializer):
    class Meta:
        model = EmployeePhoneNumber
        fields = ['EmployeeId', 'PhoneNumber']
        read_only_fields = ['EmployeeId']

class CarSerializer (serializers.ModelSerializer):
    class Meta:
        model = Car
        fields = ('CarID', 'TypeID', 'BranchID','Manufacturer', 'Model', 'FuelType', 'Colour', 
            'LicencePlate', 'Status', 'Mileage')
        read_only_fields = ['CarID']

class CarTypeSerializer (serializers.ModelSerializer):
    class Meta:
        model = CarType
        fields = ['TypeID', 'Description', 'Manufacturer', 'Model', 'FuelType','DailyCost', 'WeeklyCost', 
            'MonthlyCost', 'LateFee', 'ChangeBranchFee']
        read_only_fields = ['TypeID']

class BranchSerializer (serializers.ModelSerializer):
    class Meta:
        model = Branch
        fields = ['BranchID', 'UnitNumber', 'Province', 'City',
             'PostalCode', 'StreetNumber', 'StreetName', 'UnitNumber']
        read_only_fields = ['BranchID']

class EmployeeSerializer (serializers.ModelSerializer):
    class Meta:
        model = Employee
        fields = ['EmployeeID', 'FirstName', 'LastName', 'Email', 'Salary',
        'Rank', 'DateOfBirth', 'Province', 'City', 'PostalCode', 
        'StreetNumber', 'StreetName', 'UnitNumber', 'BranchNumber']
        read_only_fields = ['EmployeeID']

class RentalSerializer (serializers.ModelSerializer):
    class Meta:
        model = Rental
        fields = ['RentalID', 'CarID', 'CustomerID', 'EmployeeID', 
        'BranchID', 'DateFrom', 'DateTo', 'TotalCost', 'LicensePlate', 
        'GoldMember']
        read_only_fields = ['RentalID']