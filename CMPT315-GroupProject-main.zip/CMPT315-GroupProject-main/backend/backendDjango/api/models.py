from django.db import models

# Create your models here.

# note you can import the django user table
# and extend it

# If you make changes to model 
# ```
# run docker exec -it cmpt315-groupproject-backend-1 asho
# ./manage.py makemigrations
# ./manage.py migrate
# ```
# you don't **need** to run the migrate command, but the makemigrations command
# is necessary
# ### BE SURE TO ACTUALLY COMMIT AND PUSH THE NEW MIGRATIONS ###
#

class Customer(models.Model):
    CustomerID          = models.BigAutoField(primary_key=True)
    # Name
    FirstName           = models.CharField(max_length=255)
    LastName            = models.CharField(max_length=255)

    DriversLicense      = models.CharField(max_length=255)
    Email               = models.EmailField(max_length=255)
    DOB                 = models.CharField(max_length=255)
    GoldMember          = models.BooleanField(default=False)

    # Address
    Province            = models.CharField(max_length=255)
    City                = models.CharField(max_length=255)
    PostalCode          = models.CharField(max_length=255)

    #   Street
    StreetNumber        = models.CharField(max_length=255)
    StreetName          = models.CharField(max_length=255)
    UnitNumber          = models.CharField(max_length=255)

class CarType(models.Model):
    TypeID              = models.BigAutoField(primary_key=True)
    Description         = models.CharField(max_length=255)
    Manufacturer        = models.CharField(max_length=255)
    Model               = models.CharField(max_length=255)
    FuelType            = models.CharField(max_length=255)
    DailyCost           = models.DecimalField(decimal_places=2, max_digits=10)
    WeeklyCost          = models.DecimalField(decimal_places=2, max_digits=10)
    MonthlyCost         = models.DecimalField(decimal_places=2, max_digits=10)
    LateFee             = models.DecimalField(decimal_places=2, max_digits=10)
    ChangeBranchFee     = models.DecimalField(decimal_places=2, max_digits=10)

class Branch(models.Model):
    BranchID            = models.BigAutoField(primary_key=True)
    UnitNumber          = models.CharField(max_length=255)

    # Address
    Province            = models.CharField(max_length=255)
    City                = models.CharField(max_length=255)
    PostalCode          = models.CharField(max_length=255)

    #   Street
    StreetNumber        = models.CharField(max_length=255)
    StreetName          = models.CharField(max_length=255)
    UnitNumber          = models.CharField(max_length=255)

class Employee(models.Model):
    EmployeeID                 = models.BigAutoField(primary_key=True)
    # Name
    FirstName           = models.CharField(max_length=255)
    LastName            = models.CharField(max_length=255)

    Email               = models.EmailField(max_length=255)

    # password & salt omitted, will be using django's authentication

    Salary              = models.CharField(max_length=255)
    Rank                = models.CharField(max_length=255)
    DateOfBirth         = models.DateField()

    # Address
    Province            = models.CharField(max_length=255)
    City                = models.CharField(max_length=255)
    PostalCode          = models.CharField(max_length=255)

    #   Street
    StreetNumber        = models.CharField(max_length=255)
    StreetName          = models.CharField(max_length=255)
    UnitNumber          = models.CharField(max_length=255)
    BranchNumber        = models.ForeignKey(Branch,  on_delete=models.PROTECT)

class CustomerPhoneNumber(models.Model):
    CustomerID          = models.ForeignKey(Customer, on_delete=models.PROTECT)
    PhoneNumber         = models.CharField(max_length=255)

class EmployeePhoneNumber(models.Model):
    EmployeeID          = models.ForeignKey(Employee, on_delete=models.PROTECT)
    PhoneNumber         = models.CharField(max_length=255)

class BranchPhoneNumber(models.Model):
    BranchID            = models.ForeignKey(Branch, on_delete=models.PROTECT)
    PhoneNumber         = models.CharField(max_length=16)

class Car(models.Model):
    CarID            = models.BigAutoField(primary_key=True)
    TypeID           = models.ForeignKey(CarType, on_delete=models.PROTECT)
    BranchID         = models.ForeignKey(Branch, on_delete=models.PROTECT)

    Manufacturer     = models.CharField(max_length=255)
    Model            = models.CharField(max_length=255)
    FuelType         = models.CharField(max_length=255)
    Colour           = models.CharField(max_length=255)
    LicencePlate     = models.CharField(max_length=255)
    Status           = models.CharField(max_length=255)
    Mileage          = models.CharField(max_length=255)

class Rental(models.Model):
    RentalID            = models.BigAutoField(primary_key=True)
    CarID               = models.ForeignKey(Car, on_delete=models.PROTECT)
    CustomerID          = models.ForeignKey(Customer, on_delete=models.PROTECT)
    EmployeeID          = models.ForeignKey(Employee, on_delete=models.PROTECT)
    BranchID            = models.ForeignKey(Branch, on_delete=models.PROTECT)
    
    DateFrom            = models.DateTimeField(auto_now=False)
    DateTo              = models.DateTimeField(auto_now=False)
    TotalCost           = models.DecimalField(decimal_places=2, max_digits=10)
    LicensePlate        = models.CharField(max_length=16)
    GoldMember          = models.BooleanField(default=False)