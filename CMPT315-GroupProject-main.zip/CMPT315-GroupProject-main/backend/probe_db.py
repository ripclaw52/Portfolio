# this script is used by backend_start.sh
# probe the local development db to see if its up and running
# return 0 on success, 1 on failure 

import string
import pymysql
import sys


def probe_db(host: string, user: string, password: string, database: string):
    try:
        db = pymysql.connect(host=host, user=user, password=password, database=database)
        cursor = db.cursor()
        cursor.execute("SELECT VERSION()")
        results = cursor.fetchone()
        # Check if anything at all is returned
        if results:
            return True
        else:
            return False
    except pymysql.Error:
        return False


if __name__ == "__main__":
    result = probe_db("database", "django_app", "password123456", "django_app_db")
    if result:
        sys.exit(0)  # connected, got version
    else:
        sys.exit(1)  # failed to connect, or db wasn't ready
