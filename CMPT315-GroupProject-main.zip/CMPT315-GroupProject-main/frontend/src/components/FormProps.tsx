import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Checkbox from '@mui/material/Checkbox';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Button from '@mui/material/Button';
import axios from 'axios';
import { useState } from 'react';
import { createFalse } from 'typescript';

export default function FormPropsTextFields({parentFunction}:any) {
  const [fName, setFName] = useState("");
  const [lName, setLName] = useState("");
  const [license, setLicense] = useState("");
  const [email, setEmail] = useState("");
  const [dob, setDob] = useState("");
  const [goldMember, setGoldMember] = useState(false);
  const [city, setCity] = useState("");
  const [province, setProvince] = useState("");
  const [postal, setPostal] = useState("");
  const [streetNum, setStreetNum] = useState("");
  const [streetName, setStreetName] = useState("");
  const [unitNum, setUnitNum] = useState("");

  const bURL = `${window.location.origin.toString()}/api/customer/`

  const handleSubmit = () => {

    axios.post(bURL, {
      FirstName: fName,
      LastName: lName,
      DriversLicense: license,
      Email: email,
      DOB: dob,
      GoldMember: goldMember,
      Province: province,
      City: city,
      PostalCode: postal,
      StreetNumber: streetNum,
      StreetName: streetName,
      UnitNumber: unitNum
    }).then(function(response){
      console.log(response);
    }).catch(function (error){
      console.log(error);
    });

    setFName("");
    setLName("");
    setLicense("");
    setEmail("");
    setDob("");
    setGoldMember(false);
    setProvince("");
    setCity("");
    setPostal("");
    setStreetNum("");
    setStreetName("");
    setUnitNum("");

    parentFunction();
  };


  return (
    <Box
      component="form"
      sx={{
        '& .MuiTextField-root': { m: 1, width: '25ch' },
      }}
      noValidate
      autoComplete="off"
    >
      <div>
        <TextField
          required
          id="fname-field"
          label="FirstName"
          variant="filled"
          onChange={(e) => setFName(e.target.value)}
          value={fName}
        />
        <TextField
          required
          id="lname-field"
          label="LastName"
          variant="filled"
          onChange={(e) => setLName(e.target.value)}
          value={lName}
        />
        <TextField
            required
            id="license-field"
            label="DriversLicense"
            variant="filled"
            onChange={(e) => setLicense(e.target.value)}
            value={license}
          />
        <TextField
            required
            id="email-field"
            label="Email"
            variant="filled"
            onChange={(e) => setEmail(e.target.value)}
            value={email}
          />
        <TextField
            required
            id="dob-field"
            label="Date of Birth"
            variant="filled"
            onChange={(e) => setDob(e.target.value)}
            value={dob}
          />
          <div className = "checkbox">
            <FormGroup >
              <FormControlLabel control={
                <Checkbox 
                  id="goldmember-value"
                  onChange={(e) => setGoldMember(e.target.checked)}
                  value={goldMember}
                />
              } label="GoldMember?" />
            </FormGroup>
          </div>
        

        <TextField
          required
          id="province-field"
          label="Province"
          variant="filled"
          onChange={(e) => setProvince(e.target.value)}
          value={province}
        />
        <TextField
          required
          id="city-field"
          label="City"
          variant="filled"
          onChange={(e) => setCity(e.target.value)}
          value={city}
        />
        <TextField
          required
          id="postalcode-field"
          label="Postal Code"
          variant="filled"
          onChange={(e) => setPostal(e.target.value)}
          value={postal}
        />
        <TextField
          required
          id="streetnum-field"
          label="Street Number"
          variant="filled"
          onChange={(e) => setStreetNum(e.target.value)}
          value={streetNum}
        />
        <TextField
          required
          id="streename-field"
          label="Street Name"
          variant="filled"
          onChange={(e) => setStreetName(e.target.value)}
          value={streetName}
        />
        <TextField
          required
          id="unitnum-field"
          label="Unit Number"
          variant="filled"
          onChange={(e) => setUnitNum(e.target.value)}
          value={unitNum}
        />
      </div>
      <div className="buttonClass">
        <Button 
          onClick={(e) => handleSubmit()}
          variant="contained"
        >Create</Button>
      </div>
    </Box>
  );
}
