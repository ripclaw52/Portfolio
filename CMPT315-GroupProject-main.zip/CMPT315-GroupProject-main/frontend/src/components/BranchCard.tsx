import * as React from 'react';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Collapse from '@mui/material/Collapse';
import Avatar from '@mui/material/Avatar';
import IconButton, { IconButtonProps } from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import { red } from '@mui/material/colors';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Box, Button, Checkbox, Dialog, DialogActions, DialogContent, DialogTitle, FormControlLabel, FormGroup, Grid, Menu, MenuItem, Paper, TextField } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { useEffect, useState } from 'react';
import axios from 'axios';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert, { AlertProps } from '@mui/material/Alert';
import Stack from '@mui/material/Stack';

interface ExpandMoreProps extends IconButtonProps {
    expand: boolean;
  }
  
  const ExpandMore = styled((props: ExpandMoreProps) => {
    const { expand, ...other } = props;
    return <IconButton {...other} />;
  })(({ theme, expand }) => ({
    transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
    marginLeft: 'auto',
    transition: theme.transitions.create('transform', {
      duration: theme.transitions.duration.shortest,
    }),
  }));
  
  // alert for snackbar
  const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
    props,
    ref,
  ) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
  });

export default function BranchInformationCard({ branch, refresh }: any) {
    const [expandedRental, setExpandedRental] = React.useState(false);
    const [expandedEmployee, setExpandedEmployee] = React.useState(false);
    const [expandedCar, setExpandedCar] = React.useState(false);

    const [isVisible, setIsVisible] = React.useState(true);
    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    const openMenu = Boolean(anchorEl);
    const bURL = `${window.location.origin.toString()}/api/branch`

    const [allRentals, setAllRentals] = React.useState<any[]>([]);
    const [allEmployees, setAllEmployees] = React.useState<any[]>([]);
    const [allCars, setAllCars] = React.useState<any[]>([]);

    //edit
    const [openEdit, setOpenEdit] = React.useState(false);

    const [city, setCity] = useState(branch.City);
    const [province, setProvince] = useState(branch.Province);
    const [postal, setPostal] = useState(branch.PostalCode);
    const [streetNum, setStreetNum] = useState(branch.StreetNumber);
    const [streetName, setStreetName] = useState(branch.StreetName);
    const [unitNum, setUnitNum] = useState(branch.UnitNumber);

    //const [employee, setEmployee] = useState<any[]>([]);
    //const [car, setCar] = useState<any[]>([]);

    //snackbar
    const [openEditSnackbar, setOpenEditSnackbar] = useState(false);
    const [openDeleteSnackbar, setOpenDeleteSnackbar] = useState(false);


    useEffect(() => {
      axios.get(`${window.location.origin.toString()}/api/rental/`).then((response) => {
        setAllRentals(response.data);
      });

      axios.get(`${window.location.origin.toString()}/api/employee/`).then((response) => {
        setAllEmployees(response.data);
      });

      axios.get(`${window.location.origin.toString()}/api/car/`).then((response) => {
        setAllCars(response.data);
      });

    }, []);


    // handles click of settings button (MoreVertIcon)
    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    // handles close of menu popup for settings button
    const handleClose = () => {
        setAnchorEl(null);
    };

    // handles opening of edit popup
    const handleOpenEdit = () => {
        setOpenEdit(true);
    };

    // handles closing of edit popup
    const handleCloseEdit = () => {
        setOpenEdit(false);
    };

    const handleUpdate = () => {
      console.log("BRANCH ID:"+branch.BranchID);
      let url = `${bURL}/${branch.BranchID}/`;
      axios.put(url, {
        Province: province,
        City: city,
        PostalCode: postal,
        StreetNumber: streetNum,
        StreetName: streetName,
        UnitNumber: unitNum
      }).then(function (response) {
        console.log(response);
      }).catch(function (error) {
        console.log(error);
      });
    }
  
    // deletes branch in db by calling axios.delete
  const handleDelete = () => {
    axios.delete(`${bURL}/${branch.BranchID}`);
    removeElement();
  };

  // Sets visibility of card when branch is deleted
  const removeElement = () => {
    setIsVisible((prev) => !prev);
  };

  // handles the expansion of branches card
  const handleExpandClickRental = () => {
    setExpandedRental(!expandedRental);
  };
  const handleExpandClickEmployee = () => {
    setExpandedEmployee(!expandedEmployee);
  };
  const handleExpandClickCar = () => {
    setExpandedCar(!expandedCar);
  };


  // handles opening of edit snackbar
  const handleEditSnackbarClick = () => {
    setOpenEditSnackbar(true);
  };

  // handles closing of edit snackbar
  const handleEditSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenEditSnackbar(false);
  };

  // handles opening of delete snackbar
  const handleDeleteSnackbarClick = () => {
    setOpenDeleteSnackbar(true);
  };

  // handles closing of delete snackbar
  const handleDeleteSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenDeleteSnackbar(false);
  };
  
  return (
  <div>
    <Card sx={{ maxWidth: 345, display: isVisible ? 'block' : 'none' }}>
      <CardHeader
      action={
        <div>
          {/* Settings button */}
          <IconButton
            id="demo-positioned-button"
            aria-controls={openMenu ? 'demo-positioned-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={openMenu ? 'true' : undefined}
            onClick={handleClick}
          >
            <MoreVertIcon />
          </IconButton>
          <Menu
            id="demo-positioned-menu"
            aria-labelledby="demo-positioned-button"
            anchorEl={anchorEl}
            open={openMenu}
            onClose={handleClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'right',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
          >
            {/* Edit button */}
            <MenuItem onClick={() => {
              handleClose();
              handleOpenEdit();
            }}><EditIcon />Edit</MenuItem>

            {/* Delete button */}
            <MenuItem onClick={() => {
              handleClose();
              handleDeleteSnackbarClick();
              handleDelete();
            }}><DeleteIcon />Delete</MenuItem>
          </Menu>
        </div>
      }
      title={branch.StreetNumber + ' ' + branch.StreetName}
      subheader={branch.Province + ', ' + branch.City}
      />
      <CardContent>
        <Typography variant="body2" color="text.secondary">
            Address: Unit-{branch.UnitNumber}, #{branch.StreetNumber}, {branch.StreetName}, {branch.City}, {branch.Province}, {branch.PostalCode}
        </Typography>
      </CardContent>
      
        <CardActions disableSpacing>
          <Typography>Rentals</Typography>
          <ExpandMore
            expand={expandedRental}
            onClick={handleExpandClickRental}
            aria-expanded={expandedRental}
            aria-label="show more"
          ><ExpandMoreIcon />
          </ExpandMore>
        </CardActions>
        <Collapse in={expandedRental} timeout="auto" unmountOnExit>
          <CardContent>
            <Grid container spacing={2} alignItems="center" >
            <>
            {
              allRentals?.length > 0
              ? (
                  allRentals.map((rental) => (
                    ((JSON.stringify(branch.BranchID)) === (JSON.stringify(rental.BranchID))) == true ? (
                      <Grid item xs={6} >
                        <Paper sx={{ height: 50 }}>
                          {rental.RentalID}
                          {rental.DateFrom} - {rental.DateTo}
                        </Paper>
                      </Grid>
                    ) : (
                      console.log()
                ))))
              : (
              <Typography align="center" variant="subtitle2" >
                No Rentals made within this branch
              </Typography>
              )
            }
            </>
            </Grid>
          </CardContent>
        </Collapse>
      
        <CardActions disableSpacing>
          <Typography>Employees</Typography>
          <ExpandMore
            expand={expandedEmployee}
            onClick={handleExpandClickEmployee}
            aria-expanded={expandedEmployee}
            aria-label="show more"
          ><ExpandMoreIcon />
          </ExpandMore>
        </CardActions>
        <Collapse in={expandedEmployee} timeout="auto" unmountOnExit>
          <CardContent>
            <Grid container spacing={2} alignItems="center" >
            <>
            {
              allEmployees?.length > 0
              ?(
                allEmployees.map((employee) => (
                  ((JSON.stringify(branch.BranchID)) === (JSON.stringify(employee.BranchNumber))) == true ? (
                    <Grid item xs={6} >
                      <Paper sx={{ height: 50 }} >{employee.EmployeeID}: {employee.FirstName} {employee.LastName}</Paper>
                    </Grid>
                  ) : (
                    console.log()
              ))))
              :(
                <Typography align="center" variant="subtitle2" >
                  No Employees within this Branch
                </Typography>
              )
            }
            </>
            </Grid>
          </CardContent>
        </Collapse>


        <CardActions disableSpacing>
          <Typography>Cars</Typography>
          <ExpandMore
            expand={expandedCar}
            onClick={handleExpandClickCar}
            aria-expanded={expandedCar}
            aria-label="show more"
          ><ExpandMoreIcon />
          </ExpandMore>
        </CardActions>
        <Collapse in={expandedCar} timeout="auto" unmountOnExit>
          <CardContent>
            <Grid container spacing={2} alignItems="center">
              <>
              {
                allCars?.length > 0
                ?(
                  allCars.map((cars) => (
                    ((JSON.stringify(branch.BranchID)) === (JSON.stringify(cars.BranchID))) == true ? (
                      <Grid item xs={6} >
                        <Paper sx={{ height: 50 }} >{cars.CarID}: {cars.Manufacturer} {cars.Model}</Paper>
                      </Grid>
                    ):(
                      console.log()
                    )
                  ))
                )
                :(
                  <Typography align="center" variant="subtitle2" >
                    No Cars within this Branch
                  </Typography>
                )
              }
              </>
            </Grid>
          </CardContent>
        </Collapse>



    </Card>

    <div className='editBranchForm'>
      <Dialog open={openEdit} onClose={handleClose} style={{ textAlign: "center" }}>
        <DialogTitle>Edit Branch</DialogTitle>
        <DialogContent>
          <Box
            component="form"
            sx={{
                '& .MuiTextField-root': { m: 1, width: '25ch' },
            }}
            noValidate
            autoComplete="off">
            <div>
              <TextField
                required
                id="province-field"
                label="Province"
                multiline
                variant="filled"
                defaultValue={`${branch.Province}`}
                onChange={(e) => setProvince(e.target.value)}
              />
              <TextField
                required
                id="city-field"
                label="City"
                variant="filled"
                defaultValue={`${branch.City}`}
                onChange={(e) => setCity(e.target.value)}

              />
              <TextField
                required
                id="postalcode-field"
                label="Postal Code"
                variant="filled"
                defaultValue={`${branch.PostalCode}`}
                onChange={(e) => setPostal(e.target.value)}
              />
              <TextField
                required
                id="streetnum-field"
                label="Street Number"
                variant="filled"
                defaultValue={`${branch.StreetNumber}`}
                onChange={(e) => setStreetNum(e.target.value)}
              />
              <TextField
                required
                id="streename-field"
                label="Street Name"
                variant="filled"
                defaultValue={`${branch.StreetName}`}
                onChange={(e) => setStreetName(e.target.value)}
              />
              <TextField
                required
                id="unitnum-field"
                label="Unit Number"
                variant="filled"
                defaultValue={`${branch.UnitNumber}`}
                onChange={(e) => setUnitNum(e.target.value)}
              />
            </div>
          </Box>
        </DialogContent>
        <DialogActions>
            <Button onClick={
              handleCloseEdit
              }>Cancel</Button>
            <Button onClick={() => {
                handleCloseEdit();
                handleUpdate();
                refresh();
                handleEditSnackbarClick();
            }}>Update</Button>
        </DialogActions>
      </Dialog>
    </div>

    <div className='snackbar'>
        <Stack spacing={2} sx={{ width: '100%' }}>
          {/* Edit snack bar*/}
          <Snackbar open={openEditSnackbar} autoHideDuration={3000} onClose={handleEditSnackbarClose}>
            <Alert onClose={handleEditSnackbarClose} severity="success" sx={{ width: '100%' }}>
              Branch "{`${branch.StreetNumber} ${branch.StreetName}`}" has been sucessfully edited!
            </Alert>
          </Snackbar>
          {/* Delete snack bar*/}
          <Snackbar open={openDeleteSnackbar} autoHideDuration={3000} onClose={handleDeleteSnackbarClose}>
            <Alert onClose={handleDeleteSnackbarClose} severity="warning" sx={{ width: '100%' }}>
              Branch "{`${branch.StreetNumber} ${branch.StreetName}`}" has been deleted!
            </Alert>
          </Snackbar>
        </Stack>
    </div>
  </div>
  );
}