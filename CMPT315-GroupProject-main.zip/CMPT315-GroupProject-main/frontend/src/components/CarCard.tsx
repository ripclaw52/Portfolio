import * as React from 'react';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Collapse from '@mui/material/Collapse';
import Avatar from '@mui/material/Avatar';
import IconButton, { IconButtonProps } from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import { red } from '@mui/material/colors';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Box, Button, Checkbox, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, FormControlLabel, FormGroup, InputLabel, Menu, MenuItem, Select, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { useEffect, useState } from 'react';
import axios from 'axios';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert, { AlertProps } from '@mui/material/Alert';
import Stack from '@mui/material/Stack';

interface ExpandMoreProps extends IconButtonProps {
  expand: boolean;
}

const ExpandMore = styled((props: ExpandMoreProps) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
  marginLeft: 'auto',
  transition: theme.transitions.create('transform', {
    duration: theme.transitions.duration.shortest,
  }),
}));

// alert for snackbar
const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
  props,
  ref,
) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

export default function CustomerInformationCard({ car, refresh }: any) {
  const [expanded, setExpanded] = React.useState(false);
  const [isVisible, setIsVisible] = React.useState(true);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const openMenu = Boolean(anchorEl);

  const [allBranches, setAllBranches] = useState<any[]>([]);
  const [allCarTypes, setAllCarTypes] = useState<any[]>([]);

  const bURL = `${window.location.origin.toString()}/api/car`

  //edit
  const [openEdit, setOpenEdit] = React.useState(false);

  const [typeID, setTypeID] = useState(car.TypeID);
  const [branchID, setBranchID] = useState(car.BranchID);
  const [manufacturer, setManufacturer] = useState(car.Manufacturer);
  const [model, setModel] = useState(car.Model);
  const [fuelType, setFuelType] = useState(car.FuelType);
  const [colour, setColour] = useState(car.Colour);
  const [licencePlate, setLicencePlate] = useState(car.LicencePlate);
  const [status, setStatus] = useState(car.Status);
  const [mileage, setMileage] = useState(car.Mileage);




  //snackbar
  const [openEditSnackbar, setOpenEditSnackbar] = useState(false);
  const [openDeleteSnackbar, setOpenDeleteSnackbar] = useState(false);

  useEffect(() => {
    axios.get(`${window.location.origin.toString()}/api/branch/`).then((response) => {
        setAllBranches(response.data);
    });
    axios.get(`${window.location.origin.toString()}/api/cartype/`).then((response) => {
      setAllCarTypes(response.data);
    })
}, []);


  // handles click of settings button (MoreVertIcon)
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  // handles close of menu popup for settings button
  const handleClose = () => {
    setAnchorEl(null);
  };

  // handles opening of edit popup
  const handleOpenEdit = () => {
    setOpenEdit(true);
  };

  // handles closing of edit popup
  const handleCloseEdit = () => {
    setOpenEdit(false);
  };

  // updates customer info in db by calling axios.put
  const handleUpdate = () => {
    let url = `${bURL}/${car.CarID}/`;
    console.log(car.LicencePlate);
    axios.put(url, {
      TypeID: typeID,
      BranchID: branchID,
      Manufacturer: manufacturer,
      Model: model,
      FuelType: fuelType,
      Colour: colour,
      LicencePlate: licencePlate,
      Status: status,
      Mileage: mileage,
      
    }).then(function (response) {
      console.log(response);
    }).catch(function (error) {
      console.log(error);
    });
  }

  // deletes customer in db by calling axios.delete
  const handleDelete = () => {
    axios.delete(`${bURL}/${car.CarID}`)
    removeElement();
  };

  // Sets visibility of card when customer is deleted
  const removeElement = () => {
    setIsVisible((prev) => !prev);
  };

  // handles the expansion of customer card
  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  const getRandomValue = () => {
    var tmp: Date = new Date();
    var val = tmp.valueOf();
    return val
  }

  // handles opening of edit snackbar
  const handleEditSnackbarClick = () => {
    setOpenEditSnackbar(true);
  };

  // handles closing of edit snackbar
  const handleEditSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenEditSnackbar(false);
  };

  // handles opening of delete snackbar
  const handleDeleteSnackbarClick = () => {
    setOpenDeleteSnackbar(true);
  };

  // handles closing of delete snackbar
  const handleDeleteSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenDeleteSnackbar(false);
  };

  return (
    <div>
      <Card sx={{ 
          minWidth: 365,
          maxWidth: 500, 
          display: isVisible ? 'block' : 'none'
          }}>
        <CardHeader
          avatar={
            <Avatar sx={{ bgcolor: car.Status === 'Available' ? "#06D718" : "#C60E11" }} aria-label="Car">
              {`${car.Manufacturer}`}
            </Avatar>
          }
          action={
            <div>
              {/* Settings button */}
              <IconButton
                id="demo-positioned-button"
                aria-controls={openMenu ? 'demo-positioned-menu' : undefined}
                aria-haspopup="true"
                aria-expanded={openMenu ? 'true' : undefined}
                onClick={handleClick}
              >
                <MoreVertIcon />
              </IconButton>
              <Menu
                id="demo-positioned-menu"
                aria-labelledby="demo-positioned-button"
                anchorEl={anchorEl}
                open={openMenu}
                onClose={handleClose}
                anchorOrigin={{
                  vertical: 'bottom',
                  horizontal: 'right',
                }}
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
              >
                {/* Edit button */}
                <MenuItem onClick={() => {
                  handleClose();
                  handleOpenEdit();
                }}><EditIcon />Edit</MenuItem>

                {/* Delete button */}
                <MenuItem onClick={() => {
                  handleClose();
                  handleDeleteSnackbarClick();
                  handleDelete();
                }}><DeleteIcon />Delete</MenuItem>
              </Menu>
            </div>
          }
          title={
            <Typography>
              <Box sx={{ fontSize: 'h2.fontsize', fontWeight: 'bold'}}>
                {car.Manufacturer + ' ' + car.Model}
              </Box>
              
            </Typography>
            
          }
          subheader={
            <Typography sx={{
              color: car.Status === 'Available' ? "#06D718" : "#C60E11"
            }} >{car.Status}</Typography>
          }
        />
        {/* Customer information */}
        
        <CardContent>
          <Box>
            <TableContainer>
              <Table size="small" >
                <TableHead>
                  <TableRow>
                    <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>Colour</Box> </Typography> </TableCell>
                    <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>FuelType</Box> </Typography> </TableCell>
                    <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>Mileage</Box> </Typography> </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell>{car.Colour}</TableCell>
                    <TableCell>{car.FuelType}</TableCell>
                    <TableCell>{car.Mileage}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </CardContent>
        <CardActions disableSpacing>
          <ExpandMore
            expand={expanded}
            onClick={handleExpandClick}
            aria-expanded={expanded}
            aria-label="show more"
          >
            <ExpandMoreIcon />
          </ExpandMore>
        </CardActions>
        <Collapse in={expanded} timeout="auto" unmountOnExit>
          <CardContent>
          <Box>
            <TableContainer>
              <Table size="small" >
                <TableHead>
                  <TableRow>
                    <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>Plate</Box> </Typography> </TableCell>
                    <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>TypeID</Box> </Typography> </TableCell>
                    <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>BranchID</Box> </Typography> </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell>{car.LicencePlate.toUpperCase()}</TableCell>
                    <TableCell>{car.TypeID}</TableCell>
                    <TableCell>{car.BranchID}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
          </CardContent>
        </Collapse>
      </Card>

      <div className='editCustomerForm'>
        {/* Edit customer popup dialog */}
        <Dialog open={openEdit} onClose={handleClose} style={{ textAlign: "center" }}>
          <DialogTitle >Edit Car</DialogTitle>
          <DialogContent>
            <Box
              component="form"
              sx={{
                '& .MuiTextField-root': { m: 1, width: '25ch' },
              }}
              noValidate
              autoComplete="off">
              <div>
                <FormControl sx={{ m: 1, width: 350, maxWidth: 225, minWidth: 100 }}>
                  <InputLabel>Select Car Type</InputLabel>
                  <Select
                      required
                      labelId="typeID-selector"
                      id="typeID-select"
                      value={typeID}
                      label="Select typeID"
                      variant="filled"
                      defaultValue={`${car.TypeID}`}
                      onChange={(e) => setTypeID(e.target.value)}>
                      {
                          allCarTypes?.length > 0
                          ? (
                              allCarTypes.map((cartype) => (
                                  <MenuItem value={cartype.TypeID} key={`${cartype.Manufacturer}${cartype.Model}:${getRandomValue()}`}>
                                  {cartype.Manufacturer} {cartype.Model}
                                  </MenuItem>
                              )))
                          : (<MenuItem>No Car Types Found</MenuItem>)
                      }
                  </Select>
                </FormControl>

                <FormControl sx={{ m: 1, width: 350, maxWidth: 225, minWidth: 100 }}>
                    <InputLabel>Select Branch</InputLabel>
                    <Select
                    required
                    labelId="branchID-selector"
                    id="branchID-select"
                    value={branchID}
                    label="Select branchID"
                    variant="filled"
                    defaultValue={`${car.BranchID}`}
                    onChange={(e) => setBranchID(e.target.value)}>
                        {
                            allBranches?.length > 0
                            ? (
                                allBranches.map((branch) => (
                                    <MenuItem value={branch.BranchID} key={`${branch.City}${branch.Province}:${getRandomValue()}`}>
                                        {branch.City} {branch.Province}
                                    </MenuItem>
                                )))
                            : (<MenuItem>No Branches Found</MenuItem>)
                        }
                    </Select>
                </FormControl>

                <TextField
                  required
                  id="manu-field"
                  label="Manufacturer"
                  multiline
                  variant="filled"
                  defaultValue={`${car.Manufacturer}`}
                  onChange={(e) => setManufacturer(e.target.value)}
                />
                <TextField
                  required
                  id="model-field"
                  label="Model"
                  variant="filled"
                  defaultValue={`${car.Model}`}
                  onChange={(e) => setModel(e.target.value)}
                />
                <TextField
                  required
                  id="FuelType-field"
                  label="FuelType"
                  variant="filled"
                  defaultValue={`${car.FuelType}`}
                  onChange={(e) => setFuelType(e.target.value)}
                />
                <TextField
                  required
                  id="Colour-field"
                  label="Colour"
                  variant="filled"
                  defaultValue={car.Colour}
                  onChange={(e) => setColour(e.target.value)}
                />
                <TextField
                  required
                  id="LicencePlate-field"
                  label="LicencePlate"
                  variant="filled"
                  defaultValue={car.LicencePlate}
                  onChange={(e) => setLicencePlate(e.target.value)}
                />
                <div className="checkbox">
                  <FormGroup >
                    <FormControlLabel control={
                      <Checkbox
                        id="Status-value"
                        value={status === 'M'? true : false}
                        defaultChecked={car.Status === 'Available' ? true : false}
                        onChange={(e) => setStatus(e.target.checked ? 'Available' : 'Rented')}
                      />
                    } label="Available?" />
                  </FormGroup>
                </div>
                <TextField
                  required
                  id="Mileage-field"
                  label="Mileage"
                  variant="filled"
                  defaultValue={`${car.Mileage}`}
                  onChange={(e) => setMileage(e.target.value)}
                />
              </div>
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={
              handleCloseEdit
            }>Cancel</Button>
            <Button onClick={() => {
              handleCloseEdit();
              handleUpdate();
              refresh();
              handleEditSnackbarClick();
            }}>Update</Button>
          </DialogActions>
        </Dialog>
      </div >

      <div className='snackbar'>
        <Stack spacing={2} sx={{ width: '100%' }}>
          {/* Edit snack bar*/}
          <Snackbar open={openEditSnackbar} autoHideDuration={3000} onClose={handleEditSnackbarClose}>
            <Alert onClose={handleEditSnackbarClose} severity="success" sx={{ width: '100%' }}>
              Car: "{`${car.Manufacturer} ${car.Model}`}" has been sucessfully edited!
            </Alert>
          </Snackbar>
          {/* Delete snack bar*/}
          <Snackbar open={openDeleteSnackbar} autoHideDuration={3000} onClose={handleDeleteSnackbarClose}>
            <Alert onClose={handleDeleteSnackbarClose} severity="warning" sx={{ width: '100%' }}>
              Car: "{`${car.Manufacturer} ${car.Model}`}" has been deleted!
            </Alert>
          </Snackbar>
        </Stack>
      </div>
    </div>
  );
}
