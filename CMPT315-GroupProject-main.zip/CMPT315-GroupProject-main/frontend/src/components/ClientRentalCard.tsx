import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { Button, ButtonProps, styled, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';

export default function ClientRentalCards({ car, totalCost, onCarSelected }: any) {


  // styles mui green button
  const ColourButton = styled(Button)<ButtonProps>(({ theme }) => ({
    color: '#000000',
    backgroundColor: '#87C00D',
    '&:hover': {
      backgroundColor: '#87C00D',
    },
  }));

  let onSelectClicked = function () {
    onCarSelected(car);
  }

  return (
    <div>
      <Card sx={{ display: 'flex' }}>
        <CardMedia
          component="img"
          sx={{ width: 300, height: 'auto' }}
          image="https://crdms.images.consumerreports.org/c_lfill,w_470,q_auto,f_auto/prod/cars/chrome/white/2019TOC040002_1280_01"
          alt="Live from space album cover"
        />
        <Box sx={{ width: '600', flexDirection: 'column' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', pl: 10, pb: 1, pt: 1 }}>
            <Typography sx={{ fontSize: '1.5em', fontWeight: 'bold' }}>
              {car.Manufacturer + ' ' + car.Model}
            </Typography>
          </Box>
          <CardContent sx={{ flex: '1 0 auto' }}>
            <Box>
              <TableContainer>
                <Table size="small" >
                  <TableHead>
                    <TableRow>
                      <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>Colour</Box> </Typography> </TableCell>
                      <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>FuelType</Box> </Typography> </TableCell>
                      <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>Mileage</Box> </Typography> </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    <TableRow>
                      <TableCell>{car.Colour}</TableCell>
                      <TableCell>{car.FuelType}</TableCell>
                      <TableCell>{car.Mileage}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          </CardContent>
          <Box sx={{ display: 'flex', alignItems: 'center', pl: 9, pb: 2 }}>
            <Typography sx={{ fontWeight: 'bold', fontSize: '1.2em' }}>
              {`Estimated total: $${totalCost}`}
            </Typography>
          </Box>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', pl: 2, pb: 1, pr: 2 }}>
          <ColourButton onClick={onSelectClicked} variant='contained' sx={{ width: '100px', height: '50px' }}>
            Select
          </ColourButton>
        </Box>

      </Card>
    </div>
  );
}