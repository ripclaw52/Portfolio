import * as React from 'react';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Collapse from '@mui/material/Collapse';
import Avatar from '@mui/material/Avatar';
import IconButton, { IconButtonProps } from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import { red } from '@mui/material/colors';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Box, Button, Checkbox, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, FormControlLabel, FormGroup, Grid, InputLabel, Menu, MenuItem, Select, SelectChangeEvent, TextField } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { useState, useEffect, useReducer } from 'react';
import axios from 'axios';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert, { AlertProps } from '@mui/material/Alert';
import Stack from '@mui/material/Stack';



interface ExpandMoreProps extends IconButtonProps {
  expand: boolean;
}

const ExpandMore = styled((props: ExpandMoreProps) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
  marginLeft: 'auto',
  transition: theme.transitions.create('transform', {
    duration: theme.transitions.duration.shortest,
  }),
}));

// alert for snackbar
const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
  props,
  ref,
) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

export default function RentalCard({ rental, refresh }: any) {
  const [expanded, setExpanded] = React.useState(false);
  const [isVisible, setIsVisible] = React.useState(true);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const openMenu = Boolean(anchorEl);
  const bURL = `${window.location.origin.toString()}`;

  const [updateLocal, forceUpdateLocal] = useReducer(x => x + 1, 0);

  const [editRentalButtonStatus, setEditRentalButtonStatus] = useState(false);
  const [allCars, setAllCars] = useState<any[]>([]);
  const [carsRefined, setCarsRefined] = useState<any[]>([]);
  const [allBranchs, setAllBranchs] = useState<any[]>([]);
  const [allEmployees, setAllEmployees] = useState<any[]>([]);
  const [employeesRefined, setEmployesRefined] = useState<any[]>([]);
  const [allCustomers, setAllCustomers] = useState<any[]>([]);
  const [carType, setCarType] = useState<any>();

  //edit
  const [openEdit, setOpenEdit] = React.useState(false);
  const [carID, setCarID] = useState(rental.CarID);
  const [customerID, setCustomerID] = useState(rental.CustomerID);
  const [employeeID, setEmployeeID] = useState(rental.EmployeeID);
  const [branchID, setBranchID] = useState(rental.BranchID);
  const [dateFrom, setDateFrom] = useState(rental.DateFrom);
  const [dateTo, setDateTo] = useState(rental.DateTo);
  const [totalCost, setTotalCost] = useState(rental.TotalCost);
  const [licensePlate, setLicensePlate] = useState(rental.LicensePlate);
  const [goldmember, setGoldmember] = useState(rental.GoldMember);

  // additional info
  const [customer, setCustomer] = useState<any>();
  const [car, setCar] = useState<any>();
  const [branch, setBranch] = useState<any>();
  const [employee, setEmployee] = useState<any>();

  //snackbar
  const [openEditSnackbar, setOpenEditSnackbar] = useState(false);
  const [openDeleteSnackbar, setOpenDeleteSnackbar] = useState(false);

  useEffect(() => {
    axios.get(`${window.location.origin.toString()}/api/car/${rental.CarID}`).then((response) => {
      setCar(response.data);
    });
    axios.get(`${window.location.origin.toString()}/api/customer/${rental.CustomerID}`).then((response) => {
      setCustomer(response.data);
    });
    axios.get(`${window.location.origin.toString()}/api/branch/${rental.BranchID}`).then((response) => {
      setBranch(response.data);
    });
    axios.get(`${window.location.origin.toString()}/api/employee/${rental.EmployeeID}`).then((response) => {
      setEmployee(response.data);
    });
    axios.get(`${window.location.origin.toString()}/api/car/`).then((response) => {
      setAllCars(response.data);
    });
    axios.get(`${window.location.origin.toString()}/api/customer/`).then((response) => {
        setAllCustomers(response.data);
    });
    axios.get(`${window.location.origin.toString()}/api/branch/`).then((response) => {
        setAllBranchs(response.data);
    });
    axios.get(`${window.location.origin.toString()}/api/employee/`).then((response) => {
        setAllEmployees(response.data);
    });
  }, [updateLocal]);


  // handles click of settings button (MoreVertIcon)
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  // handles close of menu popup for settings button
  const handleClose = () => {
    setAnchorEl(null);
  };

  // handles opening of edit popup
  const handleOpenEdit = async () => {
    setOpenEdit(true);

    var tmp:any[] = new Array(allCars.length);
    allCars.map((car) => {
        if (car.BranchID === branchID){
            tmp.push(car);
        }
    })
    await setCarsRefined(tmp);

    var tmp2:any[] = new Array(allEmployees.length);

    allEmployees.map((employee) =>{
        if (employee.BranchNumber === branchID){
            tmp2.push(employee)
        }
    })
    await setEmployesRefined(tmp2);
    
    
  };

  // handles closing of edit popup
  const handleCloseEdit = () => {
    setOpenEdit(false);
  };

  // updates customer info in db by calling axios.put
  const handleUpdate = () => {
    proccessNewRental();

    let url = `${bURL}/api/rental/${rental.RentalID}/`;
    axios.put(url, {
        CarID: carID,
        CustomerID: customerID,
        EmployeeID: employeeID,
        BranchID: branchID,
        DateFrom: dateFrom,
        DateTo: dateTo,
        TotalCost: totalCost,
        LicensePlate: licensePlate,
        GoldMember: goldmember
    }).then(function (response) {
      console.log(response);
    }).catch(function (error) {
      console.log(error);
    });

    setEditRentalButtonStatus(false);

  }

  // deletes customer in db by calling axios.delete
  const handleDelete = () => {
    axios.delete(`${bURL}/api/rental/${rental.RentalID}`)
    removeElement();
  };

  // Sets visibility of card when customer is deleted
  const removeElement = () => {
    setIsVisible((prev) => !prev);
  };

  // handles the expansion of customer card
  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  // handles opening of edit snackbar
  const handleEditSnackbarClick = () => {
    setOpenEditSnackbar(true);
  };

  // handles closing of edit snackbar
  const handleEditSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenEditSnackbar(false);
  };

  // handles opening of delete snackbar
  const handleDeleteSnackbarClick = () => {
    setOpenDeleteSnackbar(true);
  };

  // handles closing of delete snackbar
  const handleDeleteSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenDeleteSnackbar(false);
  };

  // changes the carID in a button
  const carChange = async (event: SelectChangeEvent) => {
    await setCarID(event.target.value as string);
  }

  // changes the branchID in a button
  const branchChange = async (event: SelectChangeEvent) => {
    await setBranchID(event.target.value as string);

    var bID = event.target.value as string;

    // get the array and refine the cars to match the
    // branchID
    var tmp:any[] = new Array(allCars.length);
    allCars.map((car) => {
        if (car.BranchID === bID){
            tmp.push(car);
        }
    })
    // assign the refined cars to the cars refined
    // cars state
    await setCarsRefined(tmp);

    // do the same as above but to the employees
    var tmp2:any[] = new Array(allEmployees.length);

    allEmployees.map((employee) =>{
        if (employee.BranchNumber === bID){
            tmp2.push(employee)
        }
    })
    await setEmployesRefined(tmp2);
  }

  // changes employeeID on a button
  const employeeChange = async (event: SelectChangeEvent) => {
    await setEmployeeID(event.target.value as string);
  }

  // changes customerID on a button
  const customerChange = async (event: SelectChangeEvent) => {
    await setCustomerID(event.target.value as string);

    var ind: number = +event.target.value;
    var cust = allCustomers.at(ind);
    var gm = cust.GoldMember;
    await setGoldmember(gm);
  }

  // handles the asynchronous stuff regarding useState
  // run this before the rental add button
  // then the add will always work because all of the data
  // has been loaded into their appropriate states
  const proccessNewRental = async () => {
    var carIDNum: number = +carID;

    var type = allCars.at(carIDNum).TypeID;

    await axios.get(`${window.location.origin.toString()}/api/cartype/${type}`).then((response) => {
        setCarType(response.data);
    });

    // calculate the total cost
    var dCost: number = +carType.DailyCost;

    var xx = new Date(dateFrom);
    var xy = new Date(dateTo);

    var diff = Math.abs(xy.getTime() - xx.getTime());
    var diffDays = Math.ceil(diff / (1000 * 3600 * 24));

    var cost = (diffDays * dCost).toFixed(2);

    setTotalCost(cost); // set total cost
    setEditRentalButtonStatus(true);  // set the rental edit button to false
    setLicensePlate(allCars.at(carIDNum).LicencePlate); // set the licenseplate 
  }

  // used to help aleviate all of the error codes generated when all
  // the dynamic lists get ran, but I'm not sure if it helps
  const getRandomeValue = () => {
    var tmp:Date = new Date();
    var val = tmp.valueOf();
    return val
  }

  return (
    <div>
      <Card sx={{ maxWidth: 350, display: isVisible ? 'block' : 'none' }}>
        <CardHeader
          avatar={
            <Avatar sx={{ bgcolor: red[500] }} aria-label="RentalCard">
              {`${rental.RentalID}`}
            </Avatar>
          }
          action={
            <div>
              {/* Settings button */}
              <IconButton
                id="demo-positioned-button"
                aria-controls={openMenu ? 'demo-positioned-menu' : undefined}
                aria-haspopup="true"
                aria-expanded={openMenu ? 'true' : undefined}
                onClick={handleClick}
              >
                <MoreVertIcon />
              </IconButton>
              <Menu
                id="demo-positioned-menu"
                aria-labelledby="demo-positioned-button"
                anchorEl={anchorEl}
                open={openMenu}
                onClose={handleClose}
                anchorOrigin={{
                  vertical: 'bottom',
                  horizontal: 'right',
                }}
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
              >
                {/* Edit button */}
                <MenuItem onClick={() => {
                  handleClose();
                  handleOpenEdit();
                }}><EditIcon />Edit</MenuItem>

                {/* Delete button */}
                <MenuItem onClick={() => {
                  handleClose();
                  handleDeleteSnackbarClick();
                  handleDelete();
                }}><DeleteIcon />Delete</MenuItem>
              </Menu>
            </div>
          }
          title={' RENTAL '}
          subheader={rental.GoldMember ? 'Gold Member' : 'Standard Member'}
        />
        {/* Customer information */}
        <CardContent>
          <Grid container sx={{ flexGrow: 1, maxWidth: 350, minWidth: 350 }}>
            <Grid item xs={12}>
              <Grid container justifyContent={"center"} spacing={2}>
                <Grid item>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      Customer: 
                    </Box>
                  </Typography>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      Car: 
                    </Box>
                  </Typography>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      LicensePlate: 
                    </Box>
                  </Typography>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      DateFrom: 
                    </Box>
                  </Typography>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      DateTo: 
                    </Box>
                  </Typography>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      Cost: 
                    </Box>
                  </Typography>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      Employee: 
                    </Box>
                  </Typography>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      Branch: 
                    </Box>
                  </Typography>
                  
                </Grid>
                <Grid item>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                      {customer !== undefined ? customer.FirstName : "Loading"} {customer !== undefined ? customer.LastName : "Loading"}
                    </Box>
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                    {car !== undefined ? car.Manufacturer : "Loading"} {car !== undefined ? car.Model : "Loading"}
                    </Box>
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                      {rental.LicensePlate.toUpperCase()}
                    </Box>
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                      {rental.DateFrom.slice(0, 10)}
                    </Box>
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                      {rental.DateTo.slice(0, 10)}
                    </Box>
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                      {`$${rental.TotalCost}`}
                    </Box>
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                      {employee !== undefined ? employee.FirstName : "Loading"} {employee !== undefined ? employee.LastName : "Loading"}
                    </Box>
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                      {branch !== undefined ? branch.City : "Loading"} {branch !== undefined ? branch.Province : "Loading"}
                    </Box>
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </CardContent>
        <CardActions disableSpacing>
          <ExpandMore
            expand={expanded}
            onClick={handleExpandClick}
            aria-expanded={expanded}
            aria-label="show more"
          >
            <ExpandMoreIcon />
          </ExpandMore>
        </CardActions>
        <Collapse in={expanded} timeout="auto" unmountOnExit>
          <CardContent>
          </CardContent>
        </Collapse>
      </Card>

      <div className='editCustomerForm'>
        {/* Edit customer popup dialog */}
        <Dialog open={openEdit} onClose={handleClose} style={{ textAlign: "center" }}>
          <DialogTitle >Edit Rental</DialogTitle>
          <DialogContent>
            <Box
              component="form"
              sx={{
                '& .MuiTextField-root': { m: 1, width: '25ch' },
              }}
              noValidate
              autoComplete="off">
              <div>
                <Grid container sx={{ flexGrow: 1, maxWidth: 600}}>
                      <Grid item xs={12}>
                          <Grid container justifyContent={"center"} spacing={2}>
                              <Grid item>
                                  <Box sx={{minWidth: 250, maxWidth: 200}}>
                                      <FormControl fullWidth>
                                          <InputLabel>Select Branch</InputLabel>
                                          <Select
                                              labelId="branchID-selector"
                                              id="branchID-select"
                                              value={branchID}
                                              label="Select branchID"
                                              onChange={branchChange}>
                                              {
                                                  allBranchs?.length > 0
                                                  ? (
                                                      allBranchs.map((branch) => (
                                                          <MenuItem value={branch.BranchID} key={`${branch.City}:${getRandomeValue()}`}>
                                                              {branch.City} {branch.Province}
                                                          </MenuItem>
                                                      )))
                                                  : (<MenuItem>No Branches Found</MenuItem>)
                                              } 
                                          </Select>
                                      </FormControl>
                                  </Box>
                              </Grid>
                              <Grid item>
                                  <Box sx={{minWidth: 250, maxWidth: 200}}>
                                      <FormControl fullWidth>
                                          <InputLabel>Select Car</InputLabel>
                                          <Select
                                              labelId="carID-selector"
                                              id="carID-select"
                                              value={carID}
                                              label="Select carID"
                                              onChange={carChange}>
                                              {
                                                  carsRefined?.length > 0
                                                  ? (
                                                      carsRefined.map((car) => (
                                                          <MenuItem 
                                                              value={car.CarID} 
                                                              key={`${car.Mileage}:${getRandomeValue()}`}>
                                                              {car.Manufacturer} {car.Model}
                                                          </MenuItem>
                                                      )))
                                                  : (<MenuItem>Select Branch First</MenuItem>)
                                              } 
                                          </Select>
                                      </FormControl>
                                  </Box>
                              </Grid>
                              <Grid item>
                                  <Box sx={{minWidth: 250, maxWidth: 200}}>
                                      <FormControl fullWidth>
                                          <InputLabel>Select Customer</InputLabel>
                                          <Select
                                              labelId="customerID-selector"
                                              id="customerID-select"
                                              value={customerID}
                                              label="Select customerID"
                                              onChange={customerChange}>
                                              {
                                                  allCustomers?.length > 0
                                                  ? (
                                                      allCustomers.map((customer) => (
                                                          <MenuItem value={customer.CustomerID} key={`${customer.Email}:${getRandomeValue()}`}>
                                                              {customer.FirstName} {customer.LastName}
                                                          </MenuItem>
                                                      )))
                                                  : (<MenuItem>No Customers Found</MenuItem>)
                                              } 
                                          </Select>
                                      </FormControl>
                                  </Box>
                              </Grid>
                              <Grid item>
                                  <Box sx={{minWidth: 250, maxWidth: 200}}>
                                      <FormControl fullWidth>
                                          <InputLabel>Select Employee</InputLabel>
                                          <Select
                                              required
                                              labelId="employeeID-selector"
                                              id="employeeID-select"
                                              value={employeeID}
                                              label="Select employeeID"
                                              onChange={employeeChange}>
                                              {
                                                  employeesRefined?.length > 0
                                                  ? (
                                                      employeesRefined.map((employee) => (
                                                          <MenuItem 
                                                              value={employee.EmployeeID} 
                                                              key={`${employee.Email}:${getRandomeValue()}`}>
                                                              {employee.FirstName} {employee.LastName}
                                                          </MenuItem>
                                                      )))
                                                  : (<MenuItem>Select Branch First</MenuItem>)
                                              } 
                                          </Select>
                                      </FormControl>
                                  </Box>
                              </Grid>
                          </Grid>
                      </Grid>
                  </Grid>
                  
                  
                  <TextField
                  required
                  id="province-field"
                  label="DateFrom"
                  variant="filled"
                  type="date"
                  value={dateFrom}
                  InputLabelProps={{
                      shrink:true,
                  }}
                  onChange={(e) => setDateFrom(e.target.value)}
                  />
                  <TextField
                  required
                  id="city-field"
                  label="DateTo"
                  variant="filled"
                  type="date"
                  value={dateTo}
                  InputLabelProps={{
                      shrink:true,
                  }}

                  onChange={(e) => setDateTo(e.target.value)}

                  />
                
              </div>
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseEdit}>Cancel</Button>
            <Button
                onClick={proccessNewRental} 
                >Process</Button>
            {editRentalButtonStatus ? <Button 
            onClick={() => {
            handleClose();
            handleUpdate();
            refresh();
            handleEditSnackbarClick();
            handleCloseEdit();
            }}>Update</Button> : <Button disabled>Update</Button>}
          </DialogActions>
        </Dialog>
      </div >

      <div className='snackbar'>
        <Stack spacing={2} sx={{ width: '100%' }}>
          {/* Edit snack bar*/}
          <Snackbar open={openEditSnackbar} autoHideDuration={3000} onClose={handleEditSnackbarClose}>
            <Alert onClose={handleEditSnackbarClose} severity="success" sx={{ width: '100%' }}>
              Rental has been sucessfully edited!
            </Alert>
          </Snackbar>
          {/* Delete snack bar*/}
          <Snackbar open={openDeleteSnackbar} autoHideDuration={3000} onClose={handleDeleteSnackbarClose}>
            <Alert onClose={handleDeleteSnackbarClose} severity="warning" sx={{ width: '100%' }}>
              Rental has been deleted!
            </Alert>
          </Snackbar>
        </Stack>
      </div>
    </div>
  );
}
