import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Menu from '@mui/material/Menu';
import MenuIcon from '@mui/icons-material/Menu';
import Container from '@mui/material/Container';
import Button, { ButtonProps } from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import { Link } from 'react-router-dom';
import styled from '@emotion/styled';
import './ResponsiveAppBar.css';

const pages = ['branches', 'cars', 'customers', 'employees', 'rentals'];
const clientPages = ['reserve', 'locations'];
let isAdmin = false;

export default function ResponsiveAppBar({ refresh }: any) {
    const [anchorElNav, setAnchorElNav] = React.useState<null | HTMLElement>(null);

    const handleOpenNavMenu = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorElNav(event.currentTarget);
    };

    const handleCloseNavMenu = () => {
        setAnchorElNav(null);
    };

    // handles "client" button click
    const handleBtnClick = () => {
        isAdmin = !(isAdmin);
        refresh();
    }

    // styles mui green button
    const ColorButton = styled(Button)<ButtonProps>(({ theme }) => ({
        color: '#000000',
        backgroundColor: '#87C00D',
        '&:hover': {
            backgroundColor: '#87C00D',
        },
    }));

    return (
        <AppBar position="static" style={{ background: '#1B1B1B' }}>
            <Container maxWidth="xl">
                <Toolbar disableGutters>

                    {/* Web logo */}
                    <Typography
                        variant="h6"
                        noWrap
                        component="a"
                        sx={{
                            mr: 2,
                            display: { xs: 'none', md: 'flex' },
                            fontFamily: 'monospace',
                            fontWeight: 700,
                            letterSpacing: '.3rem',
                            color: 'inherit',
                            textDecoration: 'none',
                        }}
                    >
                        {isAdmin ? (
                            <Link style={{ textDecoration: "none" }} to={`/admin`}>
                                <div className='client-logo'>
                                    a
                                    <span className='green-letters'>d</span>
                                    m
                                    <span className='green-letters' >i</span>
                                    n
                                    <span className='green-letters' >.</span>
                                </div>
                            </Link>
                        ) : (
                            <Link style={{ textDecoration: "none" }}
                                to={`/`}>
                                <div className='client-logo'>
                                    v
                                    <span className='green-letters'>r</span>
                                    o
                                    <span className='green-letters' >o</span>
                                    m
                                    <span className='green-letters' >.</span>
                                </div>
                            </Link>
                        )}
                    </Typography>

                    {/* Mobile navigation */}
                    <Box sx={{ flexGrow: 1, display: { xs: 'flex', md: 'none' } }}>
                        <IconButton
                            size="large"
                            aria-label="account of current user"
                            aria-controls="menu-appbar"
                            aria-haspopup="true"
                            onClick={handleOpenNavMenu}
                            color="inherit"
                        >
                            <MenuIcon />
                        </IconButton>
                        <Menu
                            id="menu-appbar"
                            anchorEl={anchorElNav}
                            anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'left',
                            }}
                            keepMounted
                            transformOrigin={{
                                vertical: 'top',
                                horizontal: 'left',
                            }}
                            open={Boolean(anchorElNav)}
                            onClose={handleCloseNavMenu}
                            sx={{
                                display: { xs: 'block', md: 'none' },
                            }}
                        >
                            {isAdmin ? (
                                pages.map((page) => (
                                    <MenuItem key={page} onClick={handleCloseNavMenu}>
                                        <Typography textAlign="center">
                                            <Link style={{ textDecoration: "none", color: "#212121" }} to={`/admin/${page}/`}>{page.toUpperCase()}</Link>
                                        </Typography>
                                    </MenuItem>
                                ))
                            ) : (
                                clientPages.map((page) => (
                                    <MenuItem key={page} onClick={handleCloseNavMenu}>
                                        <Typography textAlign="center">
                                            <Link style={{ textDecoration: "none", color: "#212121" }} to={`/${page}/`}>{page.toUpperCase()}</Link>
                                        </Typography>
                                    </MenuItem>
                                ))
                            )}

                        </Menu>
                    </Box>

                    {/* mobile logo */}
                    <Typography
                        variant="h5"
                        noWrap
                        component="a"
                        sx={{
                            mr: 2,
                            display: { xs: 'flex', md: 'none' },
                            flexGrow: 1,
                            fontFamily: 'monospace',
                            fontWeight: 700,
                            letterSpacing: '.3rem',
                            color: 'inherit',
                            textDecoration: 'none',
                        }}
                    >
                        {isAdmin ? (
                            <Link style={{ textDecoration: "none", color: "#fff" }} to={`/admin`}>
                                <div className='client-logo'>
                                    a
                                    <span className='green-letters'>d</span>
                                    m
                                    <span className='green-letters' >i</span>
                                    n
                                    <span className='green-letters' >.</span>
                                </div>
                            </Link>
                        ) : (
                            <Link style={{ textDecoration: "none", color: "#fff" }}
                                to={`/`}>
                                <div className='client-logo'>
                                    v
                                    <span className='green-letters'>r</span>
                                    o
                                    <span className='green-letters' >o</span>
                                    m.
                                </div>
                            </Link>
                        )}
                    </Typography>

                    {/* Web navigation links */}
                    <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
                        {isAdmin ? (
                            pages.map((page) => (
                                <Button
                                    key={page}
                                    onClick={handleCloseNavMenu}
                                    sx={{ my: 2, color: 'white', display: 'block' }}
                                >
                                    <Link style={{ textDecoration: "none", color: "white" }} to={`/admin/${page}/`}>{page}</Link>
                                </Button>
                            ))
                        ) : (
                            clientPages.map((page) => (
                                <Button
                                    key={page}
                                    onClick={handleCloseNavMenu}
                                    sx={{ my: 2, color: 'white', display: 'block' }}
                                >
                                    <Link style={{ textDecoration: "none", color: "white" }} to={`/${page}/`}>{page}</Link>
                                </Button>
                            ))
                        )}

                    </Box>

                    {/* Switch client/admin button */}
                    <Box sx={{ flexGrow: 0 }} >
                        
                            <ColorButton onClick={handleBtnClick} style={{ borderRadius: 25, minWidth: '110px' }}>
                                {isAdmin ? (
                                    <Link to="/" style={{ textDecoration: "none", color: '#1B1B1B' }}><b>Client</b></Link>
                                ) : (
                                    <Link to="/admin" style={{ textDecoration: "none",  color: '#1B1B1B' }}><b>Admin</b></Link>
                                )}
                            </ColorButton>
                        
                    </Box>

                </Toolbar>
            </Container>
        </AppBar>
    );
};
