import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import './PopularSection.css';

export default function PopularSection() {

    const fireEmoji = 'https://emojipedia-us.s3.amazonaws.com/source/skype/289/fire_1f525.png'

    return (
        <div className="popular-container">
            <h1 className="popular-title">
                <img className="fire" src={fireEmoji} alt="fire" />
                <b>Popular vehicles</b>
                <img className="fire" src={fireEmoji} alt="fire" />
            </h1>
            <div className='cards-container'>

                {/* Lambo Aventador card */}
                <Box textAlign='center' sx={{ minWidth: 275, maxWidth: 500 }}>
                    <Card style={{ border: "none", boxShadow: "none" }}><CardContent>
                        <Typography variant="h5" component="div">
                            <b>Aventador</b>
                        </Typography>
                        <Typography sx={{ mb: 1.5 }} color="text.secondary">
                            Lamborghini
                        </Typography>
                        <img className='car-img' src={require('../../images/lambo.png')} alt="lambo car" />

                        <Typography variant="body2">
                            <b>"DESIGNED TO PUSH BEYOND PERFORMANCE"</b>
                            <br />
                            The Aventador advances every concept of performance, immediately establishing itself as the benchmark
                            for the super sports car sector. Giving a glimpse of the future today, it comes from a family of supercars
                            already considered legendary.
                        </Typography>
                    </CardContent>
                        <CardActions style={{ justifyContent: 'center' }}>
                            <Button className='learnmore-btn' variant='outlined' size="small" color='success'>Learn More</Button>
                        </CardActions>
                    </Card>
                </Box>

                {/* Honda Accord card */}
                <Box textAlign='center' sx={{ minWidth: 275, maxWidth: 500 }}>
                    <Card style={{ border: "none", boxShadow: "none" }}><CardContent>
                        <Typography variant="h5" component="div">
                            <b>Accord Sedan</b>
                        </Typography>
                        <Typography sx={{ mb: 1.5 }} color="text.secondary">
                            Honda
                        </Typography>
                        <img className='car-img' src={require('../../images/honda-accord.png')} alt="lambo car" />

                        <Typography variant="body2">
                            <b>"PURE PERFORMANCE AND STYLE"</b><br />
                            The 2022 Honda Accord comes standard with a 192-horsepower turbocharged 1.5-liter four-cylinder engine.
                            A continuously variable automatic transmission (CVT) and front-wheel drive are standard. This powertrain
                            is perfectly fine for everyday driving.
                        </Typography>
                    </CardContent>
                        <CardActions style={{ justifyContent: 'center' }}>
                            <Button className='learnmore-btn' variant='outlined' size="small" color='success'>Learn More</Button>
                        </CardActions>
                    </Card>
                </Box>

                {/* Jeep wrangler card */}
                <Box textAlign='center' sx={{ minWidth: 275, maxWidth: 500 }}>
                    <Card style={{ border: "none", boxShadow: "none" }}><CardContent>
                        <Typography variant="h5" component="div">
                            <b>Wrangler</b>
                            <br />
                        </Typography>
                        <Typography sx={{ mb: 1.5 }} color="text.secondary">
                            Jeep
                        </Typography>
                        <br />
                        <br />
                        <img className='car-img' src={require('../../images/jeep-wrangler.png')} alt="lambo car" />

                        <Typography variant="body2">
                            <br />
                            <b>"THE QUICKEST, MOST POWERFUL WRANGLER EVER"</b>
                            <br />
                            The 2022 Jeep® Wrangler is the culmination of tireless innovation. Built to be tough and reliable, it takes
                            comfort and convenience to the next level while retaining its iconic style and legendary capability
                        </Typography>
                    </CardContent>
                        <CardActions style={{ justifyContent: 'center' }}>
                            <Button className='learnmore-btn' variant='outlined' size="small" color='success'>Learn More</Button>
                        </CardActions>
                    </Card>
                </Box>
            </div>
        </div>
    );
}