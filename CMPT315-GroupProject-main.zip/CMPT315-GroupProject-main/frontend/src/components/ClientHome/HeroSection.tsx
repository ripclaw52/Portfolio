import { Link } from 'react-router-dom';
import './HeroSection.css';
export default function HeroSection() {

    return (
        <div className="hero-container">

            <div className='header' >
                <h1 className='header-text'>Premium car rentals in Canada.</h1>
                <h1 className="behind-text">PREMIUM IN CANADA</h1>
                <img className='mercedes-img' src={require('../../images/mercedes.png')} alt="mercedes car" />
            </div>
            <div className='reserve-button'><Link className='neon-button' to={'/reserve'}>Reserve now</Link></div>

            <div className='arrow-scroll'>
                <div className='arrow'></div>
                <div className='arrow'></div>
                <div className='arrow'></div>
            </div>
        </div>
    );
}