import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import './AboutSection.css';
import MoneyOffIcon from '@mui/icons-material/MoneyOff';
import HighQualityIcon from '@mui/icons-material/HighQuality';
import LockIcon from '@mui/icons-material/Lock';
import SupportAgentIcon from '@mui/icons-material/SupportAgent';

export default function AboutSection() {

    return (
        <div className="about-container">

            <h1 className="">
                <b>✨ We Provide ✨</b>
            </h1>
            <h3>We will consistently deliver quality products, friendly service and great budget friendly values <br />
                that will make our customers confident with their car rental choice.</h3>
            <br />
            <br />
            <div className='about-items'>

                <CardContent sx={{ minWidth: 275, maxWidth: 100 }}>
                    <Typography sx={{ fontSize: 12 }} >
                        <MoneyOffIcon fontSize="large" />
                        <br />
                    </Typography>
                    <Typography variant="h5" component="div">
                        No hidden fees
                    </Typography>
                    <Typography sx={{ mb: 1.5, fontSize: 15 }}>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis a corrupti culpa vitae veritatis.
                    </Typography>
                </CardContent>

                <CardContent sx={{ minWidth: 275, maxWidth: 100 }}>
                    <Typography sx={{ fontSize: 12 }} >
                        <HighQualityIcon fontSize="large" />
                        <br />
                    </Typography>
                    <Typography variant="h5" component="div">
                        Quality vehicles
                    </Typography>
                    <Typography sx={{ mb: 1.5, fontSize: 15 }}>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis a corrupti culpa vitae veritatis.
                    </Typography>
                </CardContent>

                <CardContent sx={{ minWidth: 275, maxWidth: 100 }}>
                    <Typography sx={{ fontSize: 12 }} >
                        <LockIcon fontSize="large" />
                        <br />
                    </Typography>
                    <Typography variant="h5" component="div">
                        Secure transactions
                    </Typography>
                    <Typography sx={{ mb: 1.5, fontSize: 15 }}>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis a corrupti culpa vitae veritatis.
                    </Typography>
                </CardContent>

                <CardContent sx={{ minWidth: 275, maxWidth: 100 }}>
                    <Typography sx={{ fontSize: 12 }} >
                        <SupportAgentIcon fontSize="large" />
                        <br />
                    </Typography>
                    <Typography variant="h5" component="div">
                        24/7 support
                    </Typography>
                    <Typography sx={{ mb: 0.5, fontSize: 15 }}>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis a corrupti culpa vitae veritatis.
                    </Typography>
                </CardContent>
            </div>
        </div>
    );
}