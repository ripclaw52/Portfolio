import { Grid } from "@mui/material";
import React from "react";
import './Footer.css'

const hours = (
    <div className="footer-col">
        <h4>STORE HOURS</h4>
        <ul className="list-unstyled">
            <li>Monday: 9am-8pm</li>
            <li>Tuesday: 9am-8pm</li>
            <li>Wednesday: 9am-8pm</li>
            <li>Thursday: 9am-8pm</li>
            <li>Friday: 9am-9pm</li>
            <li>Saturday: 9am-9pm</li>
            <li>Sunday: 12pm-6pm</li>
        </ul>
    </div>
);

const hq = (
    <div className="footer-col">
        <h4>VROOM HQ</h4>
        <ul className="list-unstyled">
            <li>+1 780-GO-VROOM</li>
            <li>Edmonton, Alberta</li>
            <li>Canada</li>
            <li>123 Street South North</li>
        </ul>
    </div>
)

const contact = (
    <div className="footer-col">
        <h4>CONTACT US</h4>
        <ul className="list-unstyled">
            <li>Help & FAQ</li>
            <li>Contact us</li>
            <li>Online Chat</li>
            <li>Site Map</li>
        </ul>
    </div>
)

const reserve = (
    <div className="footer-col">
        <h4>RESERVATIONS</h4>
        <ul className="list-unstyled">
            <li>Start a Reservation</li>
            <li>View/Modify/Cancel</li>
            <li>Get Reciept</li>
            <li>Short-term Car Rental</li>
        </ul>
    </div>
)

const vroom = (
    <div className='client-logo'>
        v
        <span className='green-letters'>r</span>
        o
        <span className='green-letters' >o</span>
        m
        <span className='green-letters' >.</span>
    </div>
)

const copyright = (
    <div className="row">
        <p className="col-sm">
            {vroom} &copy;{new Date().getFullYear()} | All Rights Reserved | Terms of Service | Privacy
        </p>
    </div>
);

const Footer = () => {
    return (
        <div className="footer-main">
            <div className="footer-row">
                {reserve}
                {contact}
                {hq}
                {hours}
            </div>
            {copyright}
        </div>

    );
}
export default Footer;