import * as React from 'react';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Collapse from '@mui/material/Collapse';
import Avatar from '@mui/material/Avatar';
import IconButton, { IconButtonProps } from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Alert, Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, Grid, InputLabel, Menu, MenuItem, Select, Snackbar, Stack, TextField } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { useEffect, useState } from 'react';
import axios from 'axios';

interface ExpandMoreProps extends IconButtonProps {
    expand: boolean;
}

const ExpandMore = styled((props: ExpandMoreProps) => {
    const { expand, ...other } = props;
    return <IconButton {...other} />;
})(({ theme, expand }) => ({
    transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
    marginLeft: 'auto',
    transition: theme.transitions.create('transform', {
        duration: theme.transitions.duration.shortest,
    }),
}));

export default function EmployeeInformationCard({ employee, refresh }: any) {
    const [expanded, setExpanded] = React.useState(false);
    const [isVisible, setIsVisible] = React.useState(true);
    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    const openMenu = Boolean(anchorEl);

    const [allBranches, setAllBranches] = useState<any[]>([]);

    // data
    const [openEdit, setOpenEdit] = React.useState(false);
    const [fName, setFName] = useState(employee.FirstName);
    const [lName, setLName] = useState(employee.LastName);
    const [email, setEmail] = useState(employee.Email);
    const [salary, setSalary] = useState(employee.Salary);
    const [rank, setRank] = useState(employee.Rank);
    const [dob, setDob] = useState(employee.DateOfBirth);
    const [province, setProvince] = useState(employee.City);
    const [city, setCity] = useState(employee.Province);
    const [postal, setPostal] = useState(employee.PostalCode);
    const [streetNum, setStreetNum] = useState(employee.StreetNumber);
    const [streetName, setStreetName] = useState(employee.StreetName);
    const [unitNum, setUnitNum] = useState(employee.UnitNumber);
    const [branchNum, setBranchNum] = useState(employee.BranchNumber);

    // snackbar
    const [openEditSnackbar, setOpenEditSnackbar] = useState(false);
    const [openDeleteSnackbar, setOpenDeleteSnackbar] = useState(false);

    const bURL = `${window.location.origin.toString()}/api/employee`

    useEffect(() => {
        axios.get(`${window.location.origin.toString()}/api/branch/`).then((response) => {
            setAllBranches(response.data);
        });
    }, []);



    // handles click of settings button (MoreVertIcon)
    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    // handles close of menu popup for settings button
    const handleClose = () => {
        setAnchorEl(null);
    };

    // updates employee info in db by calling axios.put
    const handleEdit = () => {
        let url = `${bURL}/${employee.EmployeeID}/`;
        axios.put(url, {
            FirstName: fName,
            LastName: lName,
            Email: email,
            Salary: salary,
            Rank: rank,
            DateOfBirth: dob,
            Province: province,
            City: city,
            PostalCode: postal,
            StreetNumber: streetNum,
            StreetName: streetName,
            UnitNumber: unitNum,
            BranchNumber: branchNum
        }).then(function (response) {
            console.log(response);
        }).catch(function (error) {
            console.log(error);
        });
    }

    // deletes employee in db by calling axios.delete
    const handleDelete = () => {
        axios.delete(`${bURL}/${employee.EmployeeID}`)
        removeElement();
    };

    // Sets visibility of card when employee is deleted
    const removeElement = () => {
        setIsVisible((prev) => !prev);
    };

    // handles opening of edit popup
    const handleOpenEdit = () => {
        setOpenEdit(true);
    };

    // handles closing of edit popup
    const handleCloseEdit = () => {
        setOpenEdit(false);
    };

    // handles the expansion of employee card
    const handleExpandClick = () => {
        setExpanded(!expanded);
    };

    const getRandomValue = () => {
        var tmp: Date = new Date();
        var val = tmp.valueOf();
        return val
    }

    // handles opening of edit snackbar
    const handleEditSnackbarClick = () => {
        setOpenEditSnackbar(true);
    };

    // handles closing of edit snackbar
    const handleEditSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpenEditSnackbar(false);
    };

    // handles opening of delete snackbar
    const handleDeleteSnackbarClick = () => {
        setOpenDeleteSnackbar(true);
    };

    // handles closing of delete snackbar
    const handleDeleteSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpenDeleteSnackbar(false);
    };


    return (
        <div>
            <Card sx={{ maxWidth: 345, display: isVisible ? 'block' : 'none' }}>
                <CardHeader
                    avatar={
                        <Avatar sx={{ bgcolor: "green"}} aria-label="Employee">
                            {`${employee.FirstName[0]}`}
                        </Avatar>
                    }
                    action={
                        <div>
                            {/* Settings button */}
                            <IconButton
                                id="demo-positioned-button"
                                aria-controls={openMenu ? 'demo-positioned-menu' : undefined}
                                aria-haspopup="true"
                                aria-expanded={openMenu ? 'true' : undefined}
                                onClick={handleClick}
                            >
                                <MoreVertIcon />
                            </IconButton>
                            <Menu
                                id="demo-positioned-menu"
                                aria-labelledby="demo-positioned-button"
                                anchorEl={anchorEl}
                                open={openMenu}
                                onClose={handleClose}
                                anchorOrigin={{
                                    vertical: 'bottom',
                                    horizontal: 'right',
                                }}
                                transformOrigin={{
                                    vertical: 'top',
                                    horizontal: 'right',
                                }}
                            >
                                {/* Edit button */}
                                <MenuItem onClick={() => {
                                    handleOpenEdit();
                                    handleClose();
                                }}><EditIcon />Edit</MenuItem>

                                {/* Delete button */}
                                <MenuItem onClick={() => {
                                    handleDelete();
                                    handleDeleteSnackbarClick();
                                    handleClose();
                                }}><DeleteIcon />Delete</MenuItem>
                            </Menu>
                        </div>
                    }
                    title={employee.FirstName + ' ' + employee.LastName}
                    subheader={employee.Rank}
                />
                {/* Employee information */}
                <CardContent>
                    <Grid container sx={{ flexGrow: 1, maxWidth: 345 }}>
                        <Grid item xs={12}>
                            <Grid container justifyContent={"center"} spacing={2}>
                                <Grid item>
                                    <Typography variant="body2">
                                        <Box sx={{ textAlign: "left" }}>
                                            Branch:
                                        </Box>
                                    </Typography>
                                    <Typography variant="body2">
                                        <Box sx={{ textAlign: "left" }}>
                                            Date of Birth:
                                        </Box>
                                    </Typography>
                                    <Typography variant="body2">
                                        <Box sx={{ textAlign: "left" }}>
                                            Email:
                                        </Box>
                                    </Typography>
                                </Grid>
                                <Grid item>
                                    <Typography variant="body2" color="text.secondary">
                                        <Box sx={{ textAlign: "right" }}>
                                            {`${employee.City} , ${employee.Province}`}
                                        </Box>
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        <Box sx={{ textAlign: "right" }}>
                                            {employee.DateOfBirth}
                                        </Box>
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        <Box sx={{ textAlign: "right" }}>
                                            {employee.Email.length > 20 ? employee.Email.slice(0, 18) + "..." : employee.Email}
                                        </Box>
                                    </Typography>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                </CardContent>
                <CardActions disableSpacing>
                    <ExpandMore
                        expand={expanded}
                        onClick={handleExpandClick}
                        aria-expanded={expanded}
                        aria-label="show more"
                    >
                        <ExpandMoreIcon />
                    </ExpandMore>
                </CardActions>
                <Collapse in={expanded} timeout="auto" unmountOnExit>
                    <CardContent>
                        <Grid container sx={{ flexGrow: 1, maxWidth: 345 }}>
                            <Grid item xs={12}>
                                <Grid container justifyContent={"center"} spacing={2}>
                                    <Grid item>
                                        <Typography variant="body2">
                                            <Box sx={{ textAlign: "center" }}>
                                                Salary:
                                            </Box>
                                        </Typography>
                                        <Typography variant="body2" color="text.secondary">
                                            <Box sx={{ textAlign: "center" }}>
                                                {employee.Salary}
                                            </Box>
                                        </Typography>
                                    </Grid>
                                    <Grid item>
                                        <Typography variant="body2">
                                            <Box sx={{ textAlign: "center" }}>
                                                Date of Birth:
                                            </Box>
                                        </Typography>
                                        <Typography variant="body2" color="text.secondary">
                                            <Box sx={{ textAlign: "center" }}>
                                                {employee.DateOfBirth}
                                            </Box>
                                        </Typography>
                                    </Grid>
                                    <Grid item>
                                    <Typography variant="body2">
                                            <Box sx={{ textAlign: "center" }}>
                                                Branch ID:
                                            </Box>
                                        </Typography>
                                        <Typography variant="body2" color="text.secondary">
                                            <Box sx={{ textAlign: "center" }}>
                                                {employee.BranchNumber}
                                            </Box>
                                        </Typography>
                                    </Grid>
                                    <Grid item>
                                        <Typography variant="body2">
                                            <Box sx={{ textAlign: "center" }}>
                                                Address:
                                            </Box>
                                        </Typography>
                                        <Typography variant="body2" color="text.secondary">
                                            <Box sx={{ textAlign: "center" }}>
                                                {employee.UnitNumber + ", "
                                                    + employee.StreetNumber + " "
                                                    + employee.StreetName + " ST, "
                                                    + employee.City + ", "
                                                    + employee.Province + ", "
                                                    + employee.PostalCode}
                                            </Box>
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                    </CardContent>
                </Collapse>
            </Card>

            {/* Edit employee popup dialog */}
            <div className='editCustomerForm'>
                <Dialog open={openEdit} onClose={handleClose} style={{ textAlign: "center" }}>
                    <DialogTitle >Edit Employee</DialogTitle>
                    <DialogContent>
                        <Box
                            component="form"
                            sx={{
                                '& .MuiTextField-root': { m: 1, width: '25ch' },
                            }}
                            noValidate
                            autoComplete="off">
                            <div>
                                <TextField
                                    required
                                    id="fname-field"
                                    label="First Name"
                                    multiline
                                    variant="filled"
                                    defaultValue={`${employee.FirstName}`}

                                    onChange={(e) => setFName(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="lname-field"
                                    label="Last Name"
                                    variant="filled"
                                    defaultValue={`${employee.LastName}`}

                                    onChange={(e) => setLName(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="email-field"
                                    label="Email"
                                    variant="filled"
                                    defaultValue={`${employee.Email}`}

                                    onChange={(e) => setEmail(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="salary-field"
                                    label="Salary"
                                    variant="filled"
                                    defaultValue={`${employee.Salary}`}

                                    onChange={(e) => setSalary(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="rank-field"
                                    label="Rank"
                                    variant="filled"
                                    defaultValue={`${employee.Rank}`}

                                    onChange={(e) => setRank(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="dob-field"
                                    label="Date of Birth"
                                    variant="filled"
                                    type="date"
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    defaultValue={`${employee.DateOfBirth}`}


                                    onChange={(e) => setDob(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="province-field"
                                    label="Province"
                                    variant="filled"
                                    defaultValue={`${employee.Province}`}

                                    onChange={(e) => setProvince(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="city-field"
                                    label="City"
                                    variant="filled"
                                    defaultValue={`${employee.City}`}

                                    onChange={(e) => setCity(e.target.value)}

                                />
                                <TextField
                                    required
                                    id="postalcode-field"
                                    label="Postal Code"
                                    variant="filled"
                                    defaultValue={`${employee.PostalCode}`}

                                    onChange={(e) => setPostal(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="streetnum-field"
                                    label="Street Number"
                                    variant="filled"
                                    defaultValue={`${employee.StreetNumber}`}

                                    onChange={(e) => setStreetNum(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="streename-field"
                                    label="Street Name"
                                    variant="filled"
                                    defaultValue={`${employee.StreetName}`}

                                    onChange={(e) => setStreetName(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="unitnum-field"
                                    label="Unit Number"
                                    variant="filled"
                                    defaultValue={`${employee.UnitNumber}`}

                                    onChange={(e) => setUnitNum(e.target.value)}
                                />

                                <FormControl sx={{ m: 1, width: 400, maxWidth: 300, minWidth: 250 }}>
                                    <InputLabel>Select Branch</InputLabel>
                                    <Select
                                        labelId="branchID-selector"
                                        id="branchID-select"
                                        value={branchNum}
                                        label="Select branchID"
                                        onChange={(e) => setBranchNum(e.target.value)}>
                                        {
                                            allBranches?.length > 0
                                                ? (
                                                    allBranches.map((branch) => (
                                                        <MenuItem value={branch.BranchID} key={`${branch.City}:${getRandomValue()}`}>
                                                            {branch.City} {branch.Province}
                                                        </MenuItem>
                                                    )))
                                                : (<MenuItem>No Branches Found</MenuItem>)
                                        }
                                    </Select>
                                </FormControl>
                            </div>
                        </Box>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={
                            handleCloseEdit
                        }>Cancel</Button>
                        <Button onClick={() => {
                            handleCloseEdit();
                            handleEdit();
                            refresh();
                            handleEditSnackbarClick();
                        }}>Update</Button>
                    </DialogActions>
                </Dialog>
            </div >

            <div className='snackbar'>
                <Stack spacing={2} sx={{ width: '100%' }}>
                    {/* Edit snack bar*/}
                    <Snackbar open={openEditSnackbar} autoHideDuration={3000} onClose={handleEditSnackbarClose}>
                        <Alert onClose={handleEditSnackbarClose} severity="success" sx={{ width: '100%' }}>
                            Employee "{`${employee.FirstName} ${employee.LastName}`}" has been sucessfully edited!
                        </Alert>
                    </Snackbar>
                    {/* Delete snack bar*/}
                    <Snackbar open={openDeleteSnackbar} autoHideDuration={3000} onClose={handleDeleteSnackbarClose}>
                        <Alert onClose={handleDeleteSnackbarClose} severity="warning" sx={{ width: '100%' }}>
                            Employee "{`${employee.FirstName} ${employee.LastName}`}" has been deleted!
                        </Alert>
                    </Snackbar>
                </Stack>
            </div>

        </div>
    );
}