import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';

export default function ButtonSizes({ bsize, btext, bvariant }:any) {
  return (
      <Box>
        <Button variant = {bvariant} size = { bsize }> { btext } </Button>
      </Box>
    );
}
