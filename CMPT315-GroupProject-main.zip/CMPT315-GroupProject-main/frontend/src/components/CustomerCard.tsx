import * as React from 'react';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Collapse from '@mui/material/Collapse';
import Avatar from '@mui/material/Avatar';
import IconButton, { IconButtonProps } from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import { red } from '@mui/material/colors';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Box, Button, Checkbox, Dialog, DialogActions, DialogContent, DialogTitle, FormControlLabel, FormGroup, Grid, Menu, MenuItem, TextField } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { useState } from 'react';
import axios from 'axios';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert, { AlertProps } from '@mui/material/Alert';
import Stack from '@mui/material/Stack';

interface ExpandMoreProps extends IconButtonProps {
  expand: boolean;
}

const ExpandMore = styled((props: ExpandMoreProps) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
  marginLeft: 'auto',
  transition: theme.transitions.create('transform', {
    duration: theme.transitions.duration.shortest,
  }),
}));

// alert for snackbar
const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
  props,
  ref,
) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

export default function CustomerInformationCard({ customer, refresh }: any) {
  const [expanded, setExpanded] = React.useState(false);
  const [isVisible, setIsVisible] = React.useState(true);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const openMenu = Boolean(anchorEl);
  const bURL = `${window.location.origin.toString()}/api/customer`

  //edit
  const [openEdit, setOpenEdit] = React.useState(false);
  const [fName, setFName] = useState(customer.FirstName);
  const [lName, setLName] = useState(customer.LastName);
  const [license, setLicense] = useState(customer.DriversLicense);
  const [email, setEmail] = useState(customer.Email);
  const [dob, setDob] = useState(customer.DOB);
  const [goldMember, setGoldMember] = useState(customer.GoldMember);
  const [city, setCity] = useState(customer.Province);
  const [province, setProvince] = useState(customer.City);
  const [postal, setPostal] = useState(customer.PostalCode);
  const [streetNum, setStreetNum] = useState(customer.StreetNumber);
  const [streetName, setStreetName] = useState(customer.StreetName);
  const [unitNum, setUnitNum] = useState(customer.UnitNumber);

  //snackbar
  const [openEditSnackbar, setOpenEditSnackbar] = useState(false);
  const [openDeleteSnackbar, setOpenDeleteSnackbar] = useState(false);

  // handles click of settings button (MoreVertIcon)
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  // handles close of menu popup for settings button
  const handleClose = () => {
    setAnchorEl(null);
  };

  // handles opening of edit popup
  const handleOpenEdit = () => {
    setOpenEdit(true);
  };

  // handles closing of edit popup
  const handleCloseEdit = () => {
    setOpenEdit(false);
  };

  // updates customer info in db by calling axios.put
  const handleUpdate = () => {
    console.log("CUSTOMER ID:"+customer.CustomerID);
    let url = `${bURL}/${customer.CustomerID}/`;
    axios.put(url, {
      FirstName: fName,
      LastName: lName,
      DriversLicense: license,
      Email: email,
      DOB: dob,
      GoldMember: goldMember,
      Province: province,
      City: city,
      PostalCode: postal,
      StreetNumber: streetNum,
      StreetName: streetName,
      UnitNumber: unitNum
    }).then(function (response) {
      console.log(response);
    }).catch(function (error) {
      console.log(error);
    });
  }

  // deletes customer in db by calling axios.delete
  const handleDelete = () => {
    axios.delete(`${bURL}/${customer.CustomerID}`)
    removeElement();
  };

  // Sets visibility of card when customer is deleted
  const removeElement = () => {
    setIsVisible((prev) => !prev);
  };

  // handles the expansion of customer card
  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  // handles opening of edit snackbar
  const handleEditSnackbarClick = () => {
    setOpenEditSnackbar(true);
  };

  // handles closing of edit snackbar
  const handleEditSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenEditSnackbar(false);
  };

  // handles opening of delete snackbar
  const handleDeleteSnackbarClick = () => {
    setOpenDeleteSnackbar(true);
  };

  // handles closing of delete snackbar
  const handleDeleteSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenDeleteSnackbar(false);
  };

  return (
    <div>
      <Card sx={{ maxWidth: 345, display: isVisible ? 'block' : 'none' }}>
        <CardHeader
          avatar={
            <Avatar sx={{ bgcolor: customer.GoldMember ? "gold" : "green"}} aria-label="Customer">
              {`${customer.FirstName[0]}`}
            </Avatar>
          }
          action={
            <div>
              {/* Settings button */}
              <IconButton
                id="demo-positioned-button"
                aria-controls={openMenu ? 'demo-positioned-menu' : undefined}
                aria-haspopup="true"
                aria-expanded={openMenu ? 'true' : undefined}
                onClick={handleClick}
              >
                <MoreVertIcon />
              </IconButton>
              <Menu
                id="demo-positioned-menu"
                aria-labelledby="demo-positioned-button"
                anchorEl={anchorEl}
                open={openMenu}
                onClose={handleClose}
                anchorOrigin={{
                  vertical: 'bottom',
                  horizontal: 'right',
                }}
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
              >
                {/* Edit button */}
                <MenuItem onClick={() => {
                  handleClose();
                  handleOpenEdit();
                }}><EditIcon />Edit</MenuItem>

                {/* Delete button */}
                <MenuItem onClick={() => {
                  handleClose();
                  handleDeleteSnackbarClick();
                  handleDelete();
                }}><DeleteIcon />Delete</MenuItem>
              </Menu>
            </div>
          }
          title={customer.FirstName + ' ' + customer.LastName}
          subheader={customer.GoldMember ? 'Gold Member' : 'Standard Member'}
        />
        {/* Customer information */}
        <CardContent>
          <Grid container sx={{ flexGrow: 1, maxWidth: 345 }}>
            <Grid item xs={12}>
              <Grid container justifyContent={"center"} spacing={2}>
                <Grid item>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      Drivers License: 
                    </Box>
                  </Typography>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      Date of Birth: 
                    </Box>
                  </Typography>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      Email: 
                    </Box>
                  </Typography>
                  <Typography variant="body2">
                    <Box sx={{ textAlign: "left" }}>
                      Address: 
                    </Box>
                  </Typography>
                </Grid>
                <Grid item>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                      {customer.DriversLicense}
                    </Box>
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                      {customer.DOB}
                    </Box>
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                      {customer.Email.length > 20 ? customer.Email.slice(0, 18)+"..." : customer.Email}
                    </Box>
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <Box sx={{ textAlign: "right" }}>
                      {customer.UnitNumber+", "+ customer.StreetName.slice(0, 10) + "..." }
                    </Box>
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </CardContent>
        <CardActions disableSpacing>
          <ExpandMore
            expand={expanded}
            onClick={handleExpandClick}
            aria-expanded={expanded}
            aria-label="show more"
          >
            <Typography variant="body2" color="text.secondary">
              <Box>
                Detailed View
              </Box>
            </Typography>
            <ExpandMoreIcon />
          </ExpandMore>
        </CardActions>
        <Collapse in={expanded} timeout="auto" unmountOnExit>
          <CardContent>
            <Grid container sx={{ flexGrow: 1, maxWidth: 345 }}>
              <Grid item xs={12}>
                <Grid container justifyContent={"center"} spacing={2}>
                  <Grid item>
                    <Typography variant="body2">
                      <Box sx={{ textAlign: "center" }}>
                        Drivers License: 
                      </Box>
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      <Box sx={{ textAlign: "center" }}>
                        {customer.DriversLicense}
                      </Box>
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Typography variant="body2">
                      <Box sx={{ textAlign: "center" }}>
                        Date of Birth: 
                      </Box>
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      <Box sx={{ textAlign: "center" }}>
                        {customer.DOB}
                      </Box>
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Typography variant="body2">
                      <Box sx={{ textAlign: "center" }}>
                        Email: 
                      </Box>
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      <Box sx={{ textAlign: "center" }}>
                        {customer.Email}
                      </Box>
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Typography variant="body2">
                      <Box sx={{ textAlign: "center" }}>
                        Address: 
                      </Box>
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      <Box sx={{ textAlign: "center" }}>
                        {customer.UnitNumber+", "
                          +customer.StreetNumber+" "
                          +customer.StreetName+" ST, "
                          +customer.City+", "
                          +customer.Province+", "
                          +customer.PostalCode}
                      </Box>
                    </Typography>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </CardContent>
        </Collapse>
      </Card>

      <div className='editCustomerForm'>
        {/* Edit customer popup dialog */}
        <Dialog open={openEdit} onClose={handleClose} style={{ textAlign: "center" }}>
          <DialogTitle >Edit Customer</DialogTitle>
          <DialogContent>
            <Box
              component="form"
              sx={{
                '& .MuiTextField-root': { m: 1, width: '25ch' },
              }}
              noValidate
              autoComplete="off">
              <div>
                <TextField
                  required
                  id="fname-field"
                  label="FirstName"
                  multiline
                  variant="filled"
                  defaultValue={`${customer.FirstName}`}
                  onChange={(e) => setFName(e.target.value)}
                />
                <TextField
                  required
                  id="lname-field"
                  label="LastName"
                  variant="filled"
                  defaultValue={`${customer.LastName}`}
                  onChange={(e) => setLName(e.target.value)}
                />
                <TextField
                  required
                  id="license-field"
                  label="DriversLicense"
                  variant="filled"
                  defaultValue={`${customer.DriversLicense}`}
                  onChange={(e) => setLicense(e.target.value)}
                />
                <TextField
                  required
                  id="email-field"
                  label="Email"
                  variant="filled"
                  defaultValue={`${customer.Email}`}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <TextField
                  required
                  id="dob-field"
                  label="Date of Birth"
                  variant="filled"
                  defaultValue={`${customer.DOB}`}
                  onChange={(e) => setDob(e.target.value)}
                />
                <div className="checkbox">
                  <FormGroup >
                    <FormControlLabel control={
                      <Checkbox
                        id="goldmember-value"
                        value={goldMember}
                        defaultChecked={customer?.GoldMember}
                        onChange={(e) => setGoldMember(e.target.checked)}
                      />
                    } label="GoldMember?" />
                  </FormGroup>
                </div>
                <TextField
                  required
                  id="province-field"
                  label="Province"
                  variant="filled"
                  defaultValue={`${customer.Province}`}
                  onChange={(e) => setProvince(e.target.value)}
                />
                <TextField
                  required
                  id="city-field"
                  label="City"
                  variant="filled"
                  defaultValue={`${customer.City}`}
                  onChange={(e) => setCity(e.target.value)}

                />
                <TextField
                  required
                  id="postalcode-field"
                  label="Postal Code"
                  variant="filled"
                  defaultValue={`${customer.PostalCode}`}
                  onChange={(e) => setPostal(e.target.value)}
                />
                <TextField
                  required
                  id="streetnum-field"
                  label="Street Number"
                  variant="filled"
                  defaultValue={`${customer.StreetNumber}`}
                  onChange={(e) => setStreetNum(e.target.value)}
                />
                <TextField
                  required
                  id="streename-field"
                  label="Street Name"
                  variant="filled"
                  defaultValue={`${customer.StreetName}`}
                  onChange={(e) => setStreetName(e.target.value)}
                />
                <TextField
                  required
                  id="unitnum-field"
                  label="Unit Number"
                  variant="filled"
                  defaultValue={`${customer.UnitNumber}`}
                  onChange={(e) => setUnitNum(e.target.value)}
                />
              </div>
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={
              handleCloseEdit
            }>Cancel</Button>
            <Button onClick={() => {
              handleCloseEdit();
              handleUpdate();
              refresh();
              handleEditSnackbarClick();
            }}>Update</Button>
          </DialogActions>
        </Dialog>
      </div >

      <div className='snackbar'>
        <Stack spacing={2} sx={{ width: '100%' }}>
          {/* Edit snack bar*/}
          <Snackbar open={openEditSnackbar} autoHideDuration={3000} onClose={handleEditSnackbarClose}>
            <Alert onClose={handleEditSnackbarClose} severity="success" sx={{ width: '100%' }}>
              Customer "{`${customer.FirstName} ${customer.LastName}`}" has been sucessfully edited!
            </Alert>
          </Snackbar>
          {/* Delete snack bar*/}
          <Snackbar open={openDeleteSnackbar} autoHideDuration={3000} onClose={handleDeleteSnackbarClose}>
            <Alert onClose={handleDeleteSnackbarClose} severity="warning" sx={{ width: '100%' }}>
              Customer "{`${customer.FirstName} ${customer.LastName}`}" has been deleted!
            </Alert>
          </Snackbar>
        </Stack>
      </div>
    </div>
  );
}
