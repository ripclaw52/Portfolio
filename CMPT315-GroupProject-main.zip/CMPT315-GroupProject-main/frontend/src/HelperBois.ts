//note that daily costs comes from carType not car
export function estimateCost (dateFrom:Date, dateTo:Date, dailyCost:number) {
    var xx = dateFrom;
    var xy = dateTo;

    var diff = Math.abs(xy.getTime() - xx.getTime());
    var diffDays = Math.ceil(diff / (1000 * 3600 * 24));

    var cost = (diffDays * dailyCost).toFixed(2);

    return cost;
}