import axios from "axios";


export function postRental(postValues: any) {
    const base_url = `${window.location.origin.toString()}/api`;
    axios.post(`${base_url}/rental/`, postValues);
}

export async function getCarTypes() {
    const base_url = `${window.location.origin.toString()}/api`;
    return await axios.get(`${base_url}/cartype/`);
}

export async function getRentals() {
    const base_url = `${window.location.origin.toString()}/api`;
    return await axios.get(`${base_url}/rental/`);
}