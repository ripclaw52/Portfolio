import { useEffect, useReducer } from 'react';
import './App.css';
import ResponsiveAppBar from './components/ResponsiveAppBar';
import { Route, Routes } from 'react-router';
import Home from './pages/Home';
import Cars from './pages/Cars';
import Branches from './pages/Branches';
import Customers from './pages/Customers';
import Employees from './pages/Employees';
import Rentals from './pages/Rentals';
import ClientRentals from './pages/ClientRentals';
import Locations from './pages/Locations';
import Contact from './pages/Contact';
import AdminHome from './pages/AdminHome';

function App() {

  const [update, forceUpdate] = useReducer(x => x + 1, 0);

  useEffect(() => {
    console.log('update appbar');
  }, [update]);

  // refreshes page so that appbar updates
  const refresh = () => {
    forceUpdate();
  };

  return (
    <div className="App">
      <ResponsiveAppBar refresh={refresh} />
      <Routes>

        {/* admin */}
        <Route path='/admin' element={<AdminHome />} />
        <Route path='/admin/branches' element={<Branches />} />
        <Route path='/admin/cars' element={<Cars />} />
        <Route path='/admin/customers' element={<Customers />} />
        <Route path='/admin/employees' element={<Employees />} />
        <Route path='/admin/rentals' element={<Rentals />} />


        {/* client */}
        <Route path='/' element={<Home />} />
        <Route path='/contact/' element={<Contact />} />
        <Route path='/reserve/' element={<ClientRentals />} />
        <Route path='/locations' element={<Locations />} />
      </Routes>
    </div>
  );
}

export default App;
