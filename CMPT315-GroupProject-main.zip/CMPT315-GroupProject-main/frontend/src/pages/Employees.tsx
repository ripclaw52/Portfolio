import { useState, useEffect, useReducer } from 'react';
import EmployeeCard from './../components/EmployeeCard'
import axios from 'axios';
import { Alert, Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, InputLabel, MenuItem, Paper, Select, Snackbar, Stack, TextField, Typography } from '@mui/material';


const bURL = `${window.location.origin.toString()}/api/employee/`

export default function Customers() {
    const [edata, setEdata] = useState<any[]>([]);
    const [allBranches, setAllBranches] = useState<any[]>([]);


    const [update, forceUpdate] = useReducer(x => x + 1, 0);
    const [openAdd, setOpenAdd] = useState(false);
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

    const [fName, setFName] = useState("");
    const [lName, setLName] = useState("");
    const [email, setEmail] = useState("");
    const [salary, setSalary] = useState("");
    const [rank, setRank] = useState("");
    const [dob, setDob] = useState("");
    const [province, setProvince] = useState("");
    const [city, setCity] = useState("");
    const [postal, setPostal] = useState("");
    const [streetNum, setStreetNum] = useState("");
    const [streetName, setStreetName] = useState("");
    const [unitNum, setUnitNum] = useState("");
    const [branchNum, setBranchNum] = useState("");

    const [openAddSnackbar, setOpenAddSnackbar] = useState(false);

    useEffect(() => {
        axios.get(bURL).then((response) => {
            setEdata(response.data);
        });
        axios.get(`${window.location.origin.toString()}/api/branch/`).then((response) => {
            setAllBranches(response.data);
        });
    }, [update]);

    const handleCreateEmployee = () => {
        let url = `${bURL}`;
        axios.post(url, {
            FirstName: fName,
            LastName: lName,
            Email: email,
            Salary: salary,
            Rank: rank,
            DateOfBirth: dob,
            Province: province,
            City: city,
            PostalCode: postal,
            StreetNumber: streetNum,
            StreetName: streetName,
            UnitNumber: unitNum,
            BranchNumber: branchNum
        }).then(function (response) {
            console.log(response);
        }).catch(function (error) {
            console.log(error);
        });

        console.log(branchNum);
    }

    // refreshes cards
    const refresh = () => {
        forceUpdate();
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    // handles opening of add popup
    const handleOpenAdd = () => {
        setOpenAdd(true);
    };

    // handles closing of add popup
    const handleCloseAdd = () => {
        setOpenAdd(false);
    };

    const getRandomValue = () => {
        var tmp: Date = new Date();
        var val = tmp.valueOf();
        return val
    }

    // handles opening of add snackbar
    const handleAddSnackbarClick = () => {
        setOpenAddSnackbar(true);
    };

    // handles closing of add snackbar
    const handleAddSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpenAddSnackbar(false);
    };

    return (
        <div>
            <div>
                <h1>Employees</h1>
                <Box justifyContent="flex-end" sx={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    '& > :not(style)': {
                        p: 2,
                        mr: "5%"
                    },
                }}>
                    <Button variant="contained" onClick={handleOpenAdd} sx={{
                        color: "#1B1B1B",
                        backgroundColor: "#87C00D",
                        '&:hover': {
                            backgroundColor: '#87C00D',
                        }
                    }}>
                        <Typography>
                            <Box sx={{ fontWeight: 'bold' }}>
                                Add New Employee
                            </Box>
                        </Typography>
                    </Button>
                </Box>

            </div>
            <div>
                <Dialog open={openAdd} onClose={handleClose} style={{ textAlign: "center" }}>
                    <DialogTitle >Add Employee</DialogTitle>
                    <DialogContent>
                        <Box
                            component="form"
                            sx={{
                                '& .MuiTextField-root': { m: 1, width: '25ch' },
                            }}
                            noValidate
                            autoComplete="off">
                            <div>
                                <TextField
                                    required
                                    id="fname-field"
                                    label="First Name"
                                    multiline
                                    variant="filled"
                                    onChange={(e) => setFName(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="lname-field"
                                    label="Last Name"
                                    variant="filled"

                                    onChange={(e) => setLName(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="email-field"
                                    label="Email"
                                    variant="filled"

                                    onChange={(e) => setEmail(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="salary-field"
                                    label="Salary"
                                    variant="filled"

                                    onChange={(e) => setSalary(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="rank-field"
                                    label="Rank"
                                    variant="filled"

                                    onChange={(e) => setRank(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="dob-field"
                                    label="Date of Birth"
                                    variant="filled"
                                    type="date"
                                    InputLabelProps={{
                                        shrink: true,
                                    }}

                                    onChange={(e) => setDob(e.target.value)}

                                />
                                <TextField
                                    required
                                    id="province-field"
                                    label="Province"
                                    variant="filled"

                                    onChange={(e) => setProvince(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="city-field"
                                    label="City"
                                    variant="filled"

                                    onChange={(e) => setCity(e.target.value)}

                                />
                                <TextField
                                    required
                                    id="postalcode-field"
                                    label="Postal Code"
                                    variant="filled"

                                    onChange={(e) => setPostal(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="streetnum-field"
                                    label="Street Number"
                                    variant="filled"

                                    onChange={(e) => setStreetNum(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="streename-field"
                                    label="Street Name"
                                    variant="filled"

                                    onChange={(e) => setStreetName(e.target.value)}
                                />
                                <TextField
                                    required
                                    id="unitnum-field"
                                    label="Unit Number"
                                    variant="filled"

                                    onChange={(e) => setUnitNum(e.target.value)}
                                />

                                <FormControl sx={{ m: 1, width: 400, maxWidth: 300, minWidth: 250 }}>
                                    <InputLabel>Select Branch</InputLabel>
                                    <Select
                                        labelId="branchID-selector"
                                        id="branchID-select"
                                        value={branchNum}
                                        label="Select branchID"
                                        onChange={(e) => setBranchNum(e.target.value)}>
                                        {
                                            allBranches?.length > 0
                                                ? (
                                                    allBranches.map((branch) => (
                                                        <MenuItem value={branch.BranchID} key={`${branch.City}:${getRandomValue()}`}>
                                                            {branch.City} {branch.Province}
                                                        </MenuItem>
                                                    )))
                                                : (<MenuItem>No Branches Found</MenuItem>)
                                        }
                                    </Select>
                                </FormControl>
                            </div>
                        </Box>

                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleCloseAdd}>Cancel</Button>
                        <Button onClick={() => {
                            handleCloseAdd();
                            handleCreateEmployee();
                            handleAddSnackbarClick();
                            refresh();
                        }}>Add</Button>
                    </DialogActions>
                </Dialog>
            </div>

            <div>
                <Box
                    justifyContent="center"
                    sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        '& > :not(style)': {
                            p: 2,
                            m: 2,
                            width: '90%',
                            height: '90%',
                            bgcolor: '#C1C1C1'
                        },
                    }}>
                    <Paper>
                        <h2>List of Employees</h2>
                        {
                            edata?.length > 0
                                ? (
                                    <div className="container">
                                        {edata.map((individual) => (
                                            <div className="employeeClass">
                                                <EmployeeCard employee={individual} parentCdata={setEdata} refresh={refresh} />
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="empty">
                                        <h3>No Employees Found :(</h3>
                                    </div>
                                )
                        }
                    </Paper>
                </Box>
            </div>
            <div className='snackbar'>
                <Stack spacing={2} sx={{ width: '100%' }}>
                    {/* Add snack bar*/}
                    <Snackbar open={openAddSnackbar} autoHideDuration={3000} onClose={handleAddSnackbarClose}>
                        <Alert onClose={handleAddSnackbarClose} severity="success" sx={{ width: '100%' }}>
                            Customer "{`${fName} ${lName}`}" has been sucessfully added!
                        </Alert>
                    </Snackbar>
                </Stack>
            </div>
        </div>
    );
}