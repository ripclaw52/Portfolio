import { useState, useEffect, useReducer } from "react";
import axios from "axios";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import TextField from "@mui/material/TextField";
import Paper from "@mui/material/Paper";
import MuiAlert, { AlertProps } from '@mui/material/Alert';
import React from 'react';
import Stack from '@mui/material/Stack';
import Snackbar from "@mui/material/Snackbar";
import BranchCard from "../components/BranchCard";
import Typography from "@mui/material/Typography";

const bURL = `${window.location.origin.toString()}/api/branch/`

// alert for snackbar
const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
    props,
    ref,
  ) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
  });


export default function Branches() {
    const [bdata, setBdata] = useState<any[]>([]);
    const [update, forceUpdate] = useReducer(x => x + 1, 0);
    const [openAdd, setOpenAdd] = useState(false);
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

    const [openAddSnackbar, setOpenAddSnackbar] = useState(false);

    const [city, setCity] = useState("");
    const [province, setProvince] = useState("");
    const [postal, setPostal] = useState("");
    const [streetNum, setStreetNum] = useState("");
    const [streetName, setStreetName] = useState("");
    const [unitNum, setUnitNum] = useState("");

    //const [employee, setEmployee] = useState<any[]>([]);
    //const [car, setCar] = useState<any[]>([]);

    useEffect(() => {
        axios.get(bURL).then((response) => {
            setBdata(response.data);
        });
    }, [update]);

    const updateBranch = () => {
        axios.get(`${window.location.origin.toString()}/api/branch/`).then((response) => {
            setBdata(response.data);
        });
    };

    const refresh = () => {
        forceUpdate();
    };

    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    // handles opening of add popup
    const handleOpenAdd = () => {
        setOpenAdd(true);
    };

    // handles closing of add popup
    const handleCloseAdd = () => {
        setOpenAdd(false);
    };

    const handleCreateBranch = () => {
        let url = `${bURL}`;
        axios.post(url, {
            Province: province,
            City: city,
            PostalCode: postal,
            StreetNumber: streetNum,
            StreetName: streetName,
            UnitNumber: unitNum
        }).then(function (response) {
            console.log(response);
        }).catch(function (error) {
            console.log(error);
        });
    }

    // handles opening of edit snackbar
    const handleAddSnackbarClick = () => {
        setOpenAddSnackbar(true);
    };

    // handles closing of edit snackbar
    const handleAddSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
        return;
        }
        setOpenAddSnackbar(false);
    };

    return (
        <div>
            <div>
                <h1>Branches</h1>
                <Box justifyContent="flex-end" sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        '& > :not(style)': {
                            p: 2,
                            mr: "5%"
                        },
                    }}>
                    <Button variant="contained"
                    sx={{
                        color: "#1B1B1B",
                        backgroundColor: "#87C00D",
                        '&:hover': {
                            backgroundColor: '#87C00D',
                    }}}
                    onClick={handleOpenAdd}>
                        <Typography>
                            <Box sx={{ fontWeight: 'bold'}}>
                                Add new Branch
                            </Box>
                        </Typography>
                    </Button>
                </Box>
            </div>
            <div>
                <Dialog open={openAdd} onClose={handleClose} style={{ textAlign: "center" }}>
                    <DialogTitle>Add Branch</DialogTitle>
                    <DialogContent>
                        <Box
                        component="form"
                        sx={{
                            '& .MuiTextField-root': { m: 1, width: '25ch' },
                        }}
                        noValidate
                        autoComplete="off">
                            <div>
                            <TextField
                            required
                            id="province-field"
                            label="Province"
                            variant="filled"

                            onChange={(e) => setProvince(e.target.value)}
                            />
                            <TextField
                            required
                            id="city-field"
                            label="City"
                            variant="filled"

                            onChange={(e) => setCity(e.target.value)}

                            />
                            <TextField
                            required
                            id="postalcode-field"
                            label="Postal Code"
                            variant="filled"

                            onChange={(e) => setPostal(e.target.value)}
                            />
                            <TextField
                            required
                            id="streetnum-field"
                            label="Street Number"
                            variant="filled"

                            onChange={(e) => setStreetNum(e.target.value)}
                            />
                            <TextField
                            required
                            id="streename-field"
                            label="Street Name"
                            variant="filled"

                            onChange={(e) => setStreetName(e.target.value)}
                            />
                            <TextField
                            required
                            id="unitnum-field"
                            label="Unit Number"
                            variant="filled"

                            onChange={(e) => setUnitNum(e.target.value)}
                            />
                            </div>
                        </Box>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleCloseAdd}>Cancel</Button>
                        <Button onClick={() => {
                            handleCloseAdd();
                            handleCreateBranch();
                            refresh();
                            handleAddSnackbarClick();
                        }}>Add</Button>
                    </DialogActions>
                </Dialog>
            </div>

            <div>
                <Box
                justifyContent="center" 
                sx={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    '& > :not(style)': {
                        p: 2,
                        m: 2,
                        width: '90%',
                        height: '90%',
                        bgcolor: '#C1C1C1'
                    },
                }}>
                    <Paper>
                        <h2>List of Branches</h2>
                        {
                        bdata?.length > 0
                            ? (
                                <div className="container">
                                    {bdata.map((singleBranch) => (
                                        <div className="branchClass">
                                            {
                                            <BranchCard branch={singleBranch} refresh={refresh} />
                                            }
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="empty">
                                    <h3>No Branches Found :(</h3>
                                </div>
                            )
                        }
                    </Paper>
                </Box>
            </div>

            <div className='snackbar'>
                <Stack spacing={2} sx={{ width: '100%' }}>
                    {/* Edit snack bar*/}
                    <Snackbar open={openAddSnackbar} autoHideDuration={3000} onClose={handleAddSnackbarClose}>
                        <Alert onClose={handleAddSnackbarClose} severity="success" sx={{ width: '100%' }}>
                            Branch "{`${streetNum} ${streetName}`}" has been sucessfully added!
                        </Alert>
                    </Snackbar>
                </Stack>
            </div>
        </div>
    
    )
}