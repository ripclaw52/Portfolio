import AboutSection from "../components/ClientHome/AboutSection";
import HeroSection from "../components/ClientHome/HeroSection";
import PopularSection from "../components/ClientHome/PopularSection";
import Footer from "../components/Footer";

export default function Home() {
    return (
        <div>
            <HeroSection />
            <PopularSection />
            <AboutSection />
            <Footer />
        </div>
    );
}