import { Box, Button, ButtonProps, Card, CardContent, CardMedia, Checkbox, FormControl, FormControlLabel, FormGroup, Grid, InputLabel, MenuItem, Paper, Select, styled, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography } from "@mui/material";
import axios from "axios";
import { stringify } from "querystring";
import React from "react";
import { useEffect, useState } from "react";
import { getCarTypes, getRentals, postRental } from "../ApiWrapper";
import ClientRentalCards from "../components/ClientRentalCard";
import { estimateCost } from "../HelperBois";
import ReactConfetti from "react-confetti";

// styles mui green button
const ColourButton = styled(Button)<ButtonProps>(({ theme }) => ({
    color: '#000000',
    backgroundColor: '#87C00D',
    '&:hover': {
        backgroundColor: '#87C00D',
    },
}));

export default function ClientRentals() {
    const [isReturnVisible, setIsReturnVisible] = useState(false);
    const [formMode, setFormMode] = useState("form"); //form, listing, finished

    const [allBranches, setAllBranches] = useState<any[]>([]);
    const [allCars, setAllCars] = useState<any[]>([]);
    const [allCustomers, setAllCustomers] = useState<any[]>([]);
    const [carsRefined, setCarsRefined] = useState<any[]>([]);
    const [carTypes, setCarTypes] = useState<any[]>([]);
    const [rentals, setRentals] = useState<any[]>([]);

    const [pickupBranchID, setPickupBranchID] = useState("");
    const [pickupBranchName, setPickupBranchName] = useState("");
    const [returnBranchID, setReturnBranchID] = useState("");
    const [returnBranchName, setReturnBranchName] = useState("");
    const [pickupDate, setPickupDate] = useState("");
    const [returnDate, setReturnDate] = useState("");
    const [totalCost, setTotalCost] = useState("");
    const [selCarDailyCost, setSelCarDailyCost] = useState<any>();
    const [selectedCar, setSelectedCar] = useState({
        CarID: 0,
        TypeID: 0,
        BranchID: 0,
        Manufacturer: "",
        Model: "",
        FuelType: "",
        Colour: "",
        LicencePlate: "",
        Status: "",
        Mileage: "",
        EstimatedCost: ""
    });

    const [customerID, setCustomerID] = useState<any>();
    const [customerEmail, setCustomerEmail] = useState<any>();

    useEffect(() => {
        axios.get(`${window.location.origin.toString()}/api/branch/`).then((response) => {
            setAllBranches(response.data);
        });
        axios.get(`${window.location.origin.toString()}/api/car/`).then((response) => {
            setAllCars(response.data);
        });

        getCarTypes().then((response: any) => {
            setCarTypes(response.data);
        });

        getRentals().then((response: any) => {
            setRentals(response.data);
        });

        axios.get(`${window.location.origin.toString()}/api/customer/`).then((response) => {
            setAllCustomers(response.data);
        });

    }, []);

    const showForm = () => {
        if (!(pickupBranchID === "")) {
            allCustomers.map((cust) => {
                if (cust.Email === customerEmail){
                    setCustomerID(cust.CustomerID);
                }
            })
            allBranches.map((b) => {
                if (b.BranchID === pickupBranchID){
                    setPickupBranchName(`${b.City}, ${b.Province}`);
                }
                if (b.BranchID === returnBranchID){
                    setReturnBranchName(`${b.City}, ${b.Province}`);
                }
            })
            setFormMode("listing");
            branchChange();
        }
    };

    const branchChange = async () => {
        var bID = pickupBranchID as string;

        var tmp: any[] = new Array(allCars.length);

        
        // get the car ids that are rented out during selected time period
        let branchActiveRentals = rentals.filter(
            (r) => r.BranchID === bID && 
                   new Date(returnDate) >= new Date(r.DateFrom) && 
                   new Date(pickupDate) <= new Date(r.DateTo)
        ).map((r) => r.CarID);

        console.log("branchActiveRentals");
        console.log(branchActiveRentals);
        allCars.map((car) => {
            // exclude cars not from selected branch, and that are rented out
            if (car.BranchID === bID && !branchActiveRentals.includes(car.CarID)) {
                //ngl this is scuffed
                // get the cartype for our selected car
                const thisCarsType = carTypes.filter(
                    (ct) => ct.TypeID === car.TypeID 
                ).at(0);
                setSelCarDailyCost(thisCarsType.DailyCost);
                car.EstimatedCost = estimateCost(
                    new Date(pickupDate),
                    new Date(returnDate),
                    thisCarsType.DailyCost
                );
                tmp.push(car);
            }
        })
        await setCarsRefined(tmp);
    }

    const onCarSelected = function (car: any) {
        const rentalObj = {
            CarID: car.CarID,
            CustomerID: customerID,
            EmployeeID: 1,
            BranchID: pickupBranchID,
            DateFrom: new Date(pickupDate).toISOString(),
            DateTo: new Date(returnDate).toISOString(),
            TotalCost: car.EstimatedCost,
            LicensePlate: car.LicencePlate,
            GoldMember: true,
        };
        console.log(rentalObj);
        postRental(rentalObj);
        setSelectedCar(car);
        setFormMode("finished");
    };

    const Confetti = (
        <>
            <ReactConfetti
                width={1500}
                height={900}
                numberOfPieces={100}
                tweenDuration={1} />
        </>
    );


    const branchDateSelectForm = (
        <div className="ClientCarForm">
            <Grid direction={'column'}>
                <Grid item xs={6} paddingBottom="5px">
                    <h1>Enter your email:</h1>
                </Grid>
                <Grid item xs={6} paddingBottom="5px">
                    <TextField
                            required
                            id="email-field"
                            label="Email"
                            variant="filled"

                            onChange={(e) => setCustomerEmail(e.target.value)}

                            />
                </Grid>
                <Grid item xs={6} paddingBottom="5px">
                    <h1>Reserve a vehicle</h1>
                </Grid>
                <Grid item xs={6}>
                    {isReturnVisible ? (
                        <h3>Step 1: Pickup</h3>
                    ) : (
                        <h3>Step 1: Pickup & Return Location</h3>
                    )}
                    <FormControl sx={{ m: 1, width: 400, maxWidth: 300, minWidth: 250 }}>
                        <InputLabel>Select Branch</InputLabel>
                        <Select
                            labelId="branchID-selector"
                            id="branchID-select"
                            label="Select branchID"
                            value={pickupBranchID}
                            onChange={(e) => setPickupBranchID(e.target.value)}
                            >
                            {
                                allBranches?.length > 0
                                    ? (
                                        allBranches.map((branch) => (
                                            <MenuItem value={branch.BranchID} key={branch.BranchID}>
                                                {branch.City} {branch.Province}
                                            </MenuItem>
                                        )))
                                    : (<MenuItem>No Branches Found</MenuItem>)
                            }
                        </Select>
                    </FormControl>
                    <div className="checkbox">
                        <FormGroup >
                            <FormControlLabel control={
                                <Checkbox
                                    id="return-location"
                                    onChange={(e) => setIsReturnVisible(e.target.checked)}
                                />
                            } label="Return to a different location" />
                        </FormGroup>
                    </div>
                </Grid>
                <Grid item xs={6} display={isReturnVisible ? 'block' : 'none'}>
                    <h3>Return Location</h3>
                    <FormControl sx={{ m: 1, width: 400, maxWidth: 300, minWidth: 250 }}>
                        <InputLabel>Select Branch</InputLabel>
                        <Select
                            labelId="branchID-selector"
                            id="branchID-select"
                            label="Select branchID"
                            value={returnBranchID}
                            onChange={(e) => setReturnBranchID(e.target.value)}
                        >
                            {
                                allBranches?.length > 0
                                    ? (
                                        allBranches.map((branch) => (
                                            <MenuItem value={branch.BranchID} key={branch.BranchID}>
                                                {branch.City} {branch.Province}
                                            </MenuItem>
                                        )))
                                    : (<MenuItem>No Branches Found</MenuItem>)
                            }
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={6}>
                    <h3>Step 2: Pick-up date</h3>
                    <TextField
                        required
                        id="province-field"
                        label="Date From"
                        variant="filled"
                        type="date"
                        InputLabelProps={{
                            shrink: true,
                        }}

                        onChange={(e) => setPickupDate(e.target.value)}
                    />
                </Grid>
                <Grid item xs={6}>
                    <h3>Step 3: Return date</h3>
                    <TextField
                        required
                        id="city-field"
                        label="Date To"
                        variant="filled"
                        type="date"
                        InputLabelProps={{
                            shrink: true,
                        }}

                        onChange={(e) => setReturnDate(e.target.value)}
                    />
                </Grid>
                <Grid item xs={6} paddingTop="40px" paddingRight="40px">
                    <ColourButton onClick={showForm} sx={{ width: 220, height: 50, borderRadius: 25 }}><b>Check Availability</b></ColourButton>
                </Grid>
            </Grid>
        </div>
    );

    const carListing = (
        <Box sx={{ flexDirection: 'row' }} >
            <Paper> Filters</Paper>
            <Paper sx={{ boxShadow: 0 }}>
                {
                    carsRefined?.length > 0
                        ? (
                            <div className="container">
                                {carsRefined.map((singleCar) => (
                                    <div className="customerClass" key={singleCar.CarID}>
                                        {
                                            <ClientRentalCards car={singleCar} totalCost={singleCar.EstimatedCost} onCarSelected={onCarSelected} />
                                        }
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="empty">
                                <h3>Sorry! No Cars Found :(</h3>
                            </div>
                        )
                }
            </Paper>
        </Box>
    );

    const confirmationScreen = (
        <div>
            {Confetti}
            <Box justifyContent="center"
                    sx={{
                        display: 'flex',
                        flexWrap: 'wrap'}} >

                {/* Title */}
                <Grid container sx={{ flexGrow: 1, maxWidth: "90%", minWidth: "90%"}}>
                    <Grid item xs={12}>
                        <Grid container justifyContent={"center"} spacing={2}>
                            <Grid item>
                                <Typography variant="h3">
                                    <Box sx={{ p: 5 }}>
                                        Reservation Successful!
                                    </Box>
                                </Typography>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>

                {/* Rental Car Card */}
                <Grid container sx={{ flexGrow: 1, maxWidth: "90%", minWidth: "90%", p: 2}}>
                    <Grid item xs={12}>
                        <Grid container justifyContent={"center"} spacing={2}>
                            <Grid item>
                                <Box sx={{ flexDirection: 'column' }}>
                                    
                                    <Box sx={{ flexDirection: 'row' }} >
                                        
                                        <Paper sx={{ boxShadow: 4 }}>
                                            
                                            <Card sx={{ display: 'flex' }}>
                                                <Box sx={{
                                                    display: 'flex', 
                                                    alignItems: 'center',
                                                    p: 3 }}>
                                                    <Typography variant="h5">
                                                            Your Rental:
                                                    </Typography>
                                                </Box>
                                                <CardMedia
                                                    component="img"
                                                    sx={{ width: 300, height: 'auto' }}
                                                    image="https://crdms.images.consumerreports.org/c_lfill,w_470,q_auto,f_auto/prod/cars/chrome/white/2019TOC040002_1280_01"
                                                    alt="Live from space album cover"
                                                />
                                                <Box sx={{ width: '600', flexDirection: 'column' }}>
                                                    
                                                    <CardContent sx={{ flex: '1 0 auto' }}>
                                                        <Box sx={{ display: 'flex', alignItems: 'center', pl: 10, pb: 1, pt: 1 }}>
                                                            <Typography sx={{ fontSize: '1.5em', fontWeight: 'bold' }}>
                                                                {selectedCar.Manufacturer + ' ' + selectedCar.Model}
                                                            </Typography>
                                                        </Box>
                                                        <Box>
                                                            <TableContainer>
                                                                <Table size="small" >
                                                                    <TableHead>
                                                                        <TableRow>
                                                                            <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>Colour</Box> </Typography> </TableCell>
                                                                            <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>FuelType</Box> </Typography> </TableCell>
                                                                            <TableCell> <Typography> <Box sx={{ fontWeight: 'bold' }}>Mileage</Box> </Typography> </TableCell>
                                                                        </TableRow>
                                                                    </TableHead>
                                                                    <TableBody>
                                                                        <TableRow>
                                                                            <TableCell>{selectedCar.Colour}</TableCell>
                                                                            <TableCell>{selectedCar.FuelType}</TableCell>
                                                                            <TableCell>{selectedCar.Mileage}</TableCell>
                                                                        </TableRow>
                                                                    </TableBody>
                                                                </Table>
                                                            </TableContainer>
                                                        </Box>
                                                    </CardContent>
                                                    
                                                </Box>

                                            </Card>
                                        </Paper>
                                    </Box>


                                </Box>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>

                {/* Rental Information */}
                <Grid container sx={{ flexGrow: 1, minWidth: "300", maxWidth: 855, p: 2}}>
                    <Grid item xs={12}>
                        <Paper>
                            <Card>
                                <CardContent>
                                    <Grid container direction="row"
                                        justifyContent="space-between"
                                        alignItems="center">
                                        <Grid item >
                                            <Box sx={{ minWidth: 300, flexDirection: 'row'}}>
                                                <TableContainer>
                                                    <Table size="small" >
                                                        <TableHead>
                                                            <TableRow>
                                                                <TableCell></TableCell>
                                                                <TableCell align="center"> <Typography> <Box sx={{ fontWeight: 'bold' }}>Pickup</Box> </Typography> </TableCell>
                                                                <TableCell align="center"> <Typography> <Box sx={{ fontWeight: 'bold' }}>Dropoff</Box> </Typography> </TableCell>
                                                            </TableRow>
                                                        </TableHead>
                                                        <TableBody>
                                                            <TableRow>
                                                                <TableCell align="right"><Typography> <Box sx={{ fontWeight: 'bold' }}>Date:</Box> </Typography></TableCell>
                                                                <TableCell align="center">{pickupDate}</TableCell>
                                                                <TableCell align="center">{returnDate}</TableCell>
                                                            </TableRow>
                                                            <TableRow>
                                                                <TableCell align="right"><Typography> <Box sx={{ fontWeight: 'bold' }}>Branch:</Box> </Typography></TableCell>
                                                                <TableCell align="center">{pickupBranchName}</TableCell>
                                                                <TableCell align="center">{returnBranchName.length > 1 ? returnBranchName : pickupBranchName}</TableCell>
                                                            </TableRow>
                                                        </TableBody>
                                                    </Table>
                                                </TableContainer>
                                            </Box>
                                        </Grid>
                                        <Grid item >
                                            <Box>
                                            <TableContainer>
                                                    <Table size="small" >
                                                        <TableHead>
                                                            <TableRow>
                                                                <TableCell></TableCell>
                                                                <TableCell align="right"> <Typography> <Box sx={{ fontWeight: 'bold' }}>Receipt Breakdown</Box> </Typography> </TableCell>
                                                            </TableRow>
                                                        </TableHead>
                                                        <TableBody>
                                                            <TableRow>
                                                                <TableCell><Typography> <Box sx={{ fontWeight: 'bold' }}>Cost:</Box> </Typography></TableCell>
                                                                <TableCell align="right">${selCarDailyCost}</TableCell>
                                                            </TableRow>
                                                            <TableRow>
                                                                <TableCell><Typography> <Box sx={{ fontWeight: 'bold' }}>Subtotal:</Box> </Typography></TableCell>
                                                                <TableCell align="right">${selectedCar.EstimatedCost}</TableCell>
                                                            </TableRow>
                                                            <TableRow>
                                                                <TableCell><Typography> <Box sx={{ fontWeight: 'bold' }}>Tax:</Box> </Typography></TableCell>
                                                                <TableCell align="right">${ ((+selectedCar.EstimatedCost * 1.05) - Number(selectedCar.EstimatedCost)).toFixed(2)}</TableCell>
                                                            </TableRow>
                                                            <TableRow>
                                                                <TableCell><Typography sx={{ fontWeight: 'bold', fontSize: '1.5em' }}>Grand Total:</Typography></TableCell>
                                                                <TableCell align="right"><Typography sx={{ fontSize: '1.5em' }}>{`$${(Number(selectedCar.EstimatedCost) * 1.05).toFixed(2)}`}</Typography></TableCell>
                                                            </TableRow>
                                                        </TableBody>
                                                    </Table>
                                                </TableContainer>
                                            </Box>
                                        </Grid>
                                    </Grid>

                                </CardContent>
                            </Card>
                        </Paper>
                    </Grid>
                </Grid>

                {/* Message to Client */}
                <Grid container sx={{ flexGrow: 1, minWidth: "855", maxWidth: 855, p: 2}}>
                    <Grid item xs={12}>
                        <Grid container justifyContent={"center"} spacing={2} >
                            <Grid item >
                                <Box sx={{ boxShadow: 2}}>
                                    <Card sx={{px: 21}}>
                                        <CardContent>
                                            <Typography>
                                                <Box>
                                                    Congratulations!
                                                </Box>
                                            </Typography>
                                            <Typography>
                                                <Box>
                                                    Your reservation was successful.
                                                </Box>
                                            </Typography>
                                            <Typography>
                                                <Box>
                                                    We've sent a copy of this reservation to the email you provided.
                                                </Box>
                                            </Typography>
                                            <Typography>
                                                <Box>
                                                    Email: {customerEmail}
                                                </Box>
                                            </Typography>
                                            <Typography>
                                                <Box>
                                                    Confirmation Number: {Math.floor((Math.random() * 100000000000000000) + 1).toString()}
                                                </Box>
                                            </Typography>


                                        </CardContent>


                                    </Card>

                                </Box>

                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
                
            </Box>
            
        </div>
        
    );

    let renderFunc = (<span>{"bruh wtf"}</span>);
    switch (formMode) {
        case "form":
            renderFunc = branchDateSelectForm;
            break;
        case "listing":
            renderFunc = carListing;
            break;
        case "finished":
            renderFunc = confirmationScreen;
            break;
    }

    return renderFunc;
}