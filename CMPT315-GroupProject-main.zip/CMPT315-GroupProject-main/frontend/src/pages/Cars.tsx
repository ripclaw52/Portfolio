import { LineAxisOutlined } from '@mui/icons-material';
import { Box, Button, Checkbox, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, FormControlLabel, FormGroup, InputLabel, MenuItem, Paper, Select, TextField, Typography } from '@mui/material';
import { useState, useEffect, useReducer } from 'react';
import CarCard from './../components/CarCard';
import MuiAlert, { AlertProps } from '@mui/material/Alert';
import React from 'react';
import axios from 'axios';

const bURL = `${window.location.origin.toString()}/api/car/`

// alert for snackbar
const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
    props,
    ref,
  ) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
  });

export default function Cars(){
    const [cars, setCars ] = useState<any[]>([]);
    const [allBranches, setAllBranches] = useState<any[]>([]);
    const [allCarTypes, setAllCarTypes] = useState<any[]>([]);

    const [update, forceUpdate] = useReducer(x => x + 1, 0);
    const [openAdd, setOpenAdd] = useState(false);
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

    const [openAddSnackbar, setOpenAddSnackbar] = useState(false);

    const [carID, setCarID] = useState("");
    const [typeID, setTypeID] = useState("");
    const [branchID, setBranchID] = useState("");
    const [manufacturer, setManufacturer] = useState("");
    const [model, setModel] = useState("");
    const [fuelType, setFuelType] = useState("");
    const [colour, setColour] = useState("");
    const [licensePlate, setLicensePlate] = useState("");
    const [status, setStatus] = useState("");
    const [mileage, setMileage] = useState("");
    

    const handleCreateCar = () =>{ 
        let url = `${bURL}`;
        axios.post(url, {
            TypeID: typeID,
            BranchID: branchID,
            Manufacturer: manufacturer,
            Model: model,
            FuelType: fuelType,
            Colour: colour,
            LicencePlate: licensePlate,
            Status: status,
            Mileage: mileage
        }).then(function (response) {
          console.log(response);
        }).catch(function (error) {
          console.log(error);
        });
      }

    // refreshes cards
    const refresh = () => {
        forceUpdate();
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    // handles opening of add popup
    const handleOpenAdd = () => {
        setOpenAdd(true);
    };

    // handles closing of add popup
    const handleCloseAdd = () => {
        setOpenAdd(false);
    };

    // handles opening of edit snackbar
    const handleAddSnackbarClick = () => {
        setOpenAddSnackbar(true);
    };

    // handles closing of edit snackbar
    const handleAddSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
        return;
        }
        setOpenAddSnackbar(false);
    };

    const getRandomValue = () => {
        var tmp: Date = new Date();
        var val = tmp.valueOf();
        return val
    }


    const BASE_URL = window.location.href;

    useEffect(() => {
        axios.get(bURL).then((response) => {
            setCars(response.data);
        });
        axios.get(`${window.location.origin.toString()}/api/branch/`).then((response) => {
            setAllBranches(response.data);
        });
        axios.get(`${window.location.origin.toString()}/api/cartype/`).then((response) => {
            setAllCarTypes(response.data);
        });
    }, [update]);


    return (
        <div>
            <div>
                <h1>Cars</h1>
            </div>
            <Box justifyContent="flex-end" sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        '& > :not(style)': {
                            p: 2,
                            mr: "5%"
                        },
                    }}>
                    <Button variant="contained"
                    sx={{
                        color: "#1B1B1B",
                        backgroundColor: "#87C00D",
                        '&:hover': {
                            backgroundColor: '#87C00D',
                          }}}
                          onClick={handleOpenAdd}>
                        <Typography>
                            <Box sx={{ fontWeight: 'bold'}}>
                                Add New Car
                            </Box>
                        </Typography>
                    </Button>
                </Box>

            <div>
            <Dialog open={openAdd} onClose={handleClose} style={{ textAlign: "center" }}>
                <DialogTitle >Add Car</DialogTitle>
                    <DialogContent>
                        <Box
                        component="form"
                        sx={{
                            '& .MuiTextField-root': { m: 1, width: '25ch' },
                        }}
                        noValidate
                        autoComplete="off">
                        <div>
                            <FormControl sx={{ m: 1, width: 350, maxWidth: 225, minWidth: 100 }}>
                                <InputLabel>Select Car Type</InputLabel>
                                <Select
                                    required
                                    labelId="typeID-selector"
                                    id="typeID-select"
                                    value={typeID}
                                    label="Select typeID"
                                    variant="filled"
                                    onChange={(e) => setTypeID(e.target.value)}>
                                    {
                                        allCarTypes?.length > 0
                                        ? (
                                            allCarTypes.map((cartype) => (
                                                <MenuItem value={cartype.TypeID} key={`${cartype.Manufacturer}${cartype.LateFee}:${getRandomValue()}`}>
                                                {cartype.Manufacturer} {cartype.Model}
                                                </MenuItem>
                                            )))
                                        : (<MenuItem>No Car Types Found</MenuItem>)
                                    }
                                </Select>
                            </FormControl>

                            <FormControl sx={{ m: 1, width: 350, maxWidth: 225, minWidth: 100 }}>
                                <InputLabel>Select Branch</InputLabel>
                                <Select
                                required
                                labelId="branchID-selector"
                                id="branchID-select"
                                value={branchID}
                                label="Select branchID"
                                variant="filled"
                                onChange={(e) => setBranchID(e.target.value)}>
                                    {
                                        allBranches?.length > 0
                                        ? (
                                            allBranches.map((branch) => (
                                                <MenuItem value={branch.BranchID} key={`${branch.City}${branch.StreetName}:${getRandomValue()}`}>
                                                    {branch.City} {branch.Province}
                                                </MenuItem>
                                            )))
                                        : (<MenuItem>No Branches Found</MenuItem>)
                                    }
                                </Select>
                            </FormControl>

                            <TextField
                            required
                            id="Manufacturer-field"
                            label="Manufacturer"
                            variant="filled"
                            multiline
                            onChange={(e) => setManufacturer(e.target.value)}
                            />
                            <TextField
                            required
                            id="Model-field"
                            label="Model"
                            variant="filled"

                            onChange={(e) => setModel(e.target.value)}
                            />
                            <TextField
                            required
                            id="FuelType-field"
                            label="FuelType"
                            variant="filled"
                            
                            onChange={(e) => setFuelType(e.target.value)}
                            />
                            <TextField
                            required
                            id="Colour-field"
                            label="Colour"
                            variant="filled"

                            onChange={(e) => setColour(e.target.value)}
                            />
                            
                            <TextField
                            required
                            id="Mileage-field"
                            label="Mileage"
                            variant="filled"

                            onChange={(e) => setMileage(e.target.value)}
                            />
                            <TextField
                            required
                            id="LicencePlate-field"
                            label="LicencePlate"
                            variant="filled"

                            onChange={(e) => setLicensePlate(e.target.value)}
                            />
                            <div className="checkbox">
                                <FormGroup >
                                    <FormControlLabel control={
                                        <Checkbox
                                            id="goldmember-value"
                                            value={status}
                                            defaultChecked={false}
                                            onChange={(e) => setStatus(
                                                e.target.checked ? 'Available' : 'Rented'
                                            )}
                                        />
                                    } label="Available?" />
                                </FormGroup>
                            </div>
                        </div>
                        </Box>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleCloseAdd}>Cancel</Button>
                        <Button onClick={() => {
                        handleCloseAdd();
                        handleCreateCar();
                        refresh();
                        handleAddSnackbarClick();
                        }}>Add</Button>
                    </DialogActions>
                </Dialog>
            </div>

            <div>
                <Box 
                    justifyContent="center" 
                    sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        '& > :not(style)': {
                            p: 2,
                            m: 2,
                            width: '90%',
                            height: '90%',
                            bgcolor: '#C1C1C1'
                        },
                    }}>
                    <Paper>
                        <h2>List of Cars</h2>
                        {
                            cars?.length > 0
                            ? (
                                <div className="container">
                                    {cars.map((singleCar) => (
                                        <div className="customerClass">
                                            {
                                                <CarCard car={singleCar} refresh={refresh} />
                                            }
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="empty">
                                    <h3>No Cars Found :(</h3>
                                </div>
                            )
                        }
                    </Paper>
                </Box>
                
            </div>
        </div>

        
        
    );
}