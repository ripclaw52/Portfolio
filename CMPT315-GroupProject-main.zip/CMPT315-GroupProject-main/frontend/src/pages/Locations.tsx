import './LocationsClass.css';
import React from 'react';
import axios from 'axios';
import { useState, useEffect, useReducer } from 'react';
import { Box, Grid, Paper, Typography } from '@mui/material';



export default function Locations() {

    const [allBranches, setAllBranches] = useState<any[]>([]);
    const [update, forceUpdate] = useReducer(x => x + 1, 0);

    useEffect(() => {
        axios.get(`${window.location.origin.toString()}/api/branch/`).then((response) => {
            setAllBranches(response.data);
        });

    }, [update]);

    return (
        <div className="locations-container">
            <h1>
                Branch Locations
            </h1>
            <div>
                <Grid container sx={{ flexGrow: 1, maxWidth: 800, minWidth: 350 }}>
                    <Grid item xs={12}>
                        <Grid container justifyContent={"center"} spacing={2}>                    
                            {
                                allBranches?.length > 0
                                ? (
                                    allBranches.map((branch) => (
                                        <Grid item>
                                            <Paper>
                                                <Box sx={{ p: 3}}>
                                                    <Typography>
                                                        {branch.City}, {branch.Province}
                                                    </Typography>
                                                </Box>
                                            </Paper>
                                        </Grid>
                                    )))
                                : (<Grid item>No Branches Found</Grid>)
                            } 
                        </Grid>
                    </Grid>
                </Grid>
            </div>
            
            
        </div>
    );
}