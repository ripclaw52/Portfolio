import RentalCard from './../components/RentalCard';
import { useState, useEffect, useReducer } from 'react';
import CustomerCard from './../components/CustomerCard'
import axios from 'axios';
import { Box, Button, Checkbox, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, FormControlLabel, FormGroup, Grid, InputLabel, Menu, MenuItem, Paper, Select, SelectChangeEvent, Snackbar, TextField, Typography } from '@mui/material';
import MuiAlert, { AlertProps } from '@mui/material/Alert';
import React from 'react';
import Stack from '@mui/material/Stack';
import { BroadcastOnHomeSharp } from '@mui/icons-material';

const bURL = `${window.location.origin.toString()}/api/rental/`

// alert for snackbar
const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
    props,
    ref,
    ) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
    });
    
export default function Customers() {
    const [rentalData, setRentalData] = useState<any[]>([]);
    const [allCars, setAllCars] = useState<any[]>([]);
    const [carsRefined, setCarsRefined] = useState<any[]>([]);
    const [allBranchs, setAllBranchs] = useState<any[]>([]);
    const [allEmployees, setAllEmployees] = useState<any[]>([]);
    const [employeesRefined, setEmployesRefined] = useState<any[]>([]);
    const [allCustomers, setAllCustomers] = useState<any[]>([]);
    const [carType, setCarType] = useState<any>();
    const [car, setCar] = useState<any>();

    const [update, forceUpdate] = useReducer(x => x + 1, 0);
    const [openAdd, setOpenAdd] = useState(false);
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const [addRentalButtonStatus, setAddRentalButtonStatus] = useState(false);

    const [openAddSnackbar, setOpenAddSnackbar] = useState(false);
    
    const [carID, setCarID] = useState("");
    const [customerID, setCustomerID] = useState("");
    const [employeeID, setEmployeeID] = useState("");
    const [branchID, setBranchID] = useState("");
    const [dateFrom, setDateFrom] = useState("");
    const [dateTo, setDateTo] = useState("");
    const [totalCost, setTotalCost] = useState("");
    const [licensePlate, setLicensePlate] = useState("");
    const [goldmember, setGoldmember] = useState("");

    
    useEffect(() => {
        axios.get(bURL).then((response) => {
            setRentalData(response.data);
        });
        axios.get(`${window.location.origin.toString()}/api/car/`).then((response) => {
            setAllCars(response.data);
        });
        axios.get(`${window.location.origin.toString()}/api/customer/`).then((response) => {
            setAllCustomers(response.data);
        });
        axios.get(`${window.location.origin.toString()}/api/branch/`).then((response) => {
            setAllBranchs(response.data);
        });
        axios.get(`${window.location.origin.toString()}/api/employee/`).then((response) => {
            setAllEmployees(response.data);
        });
    }, [update]);

    const updateRentals = () => {
        axios.get(`${window.location.origin.toString()}/api/rental/`).then((response) => {
            setRentalData(response.data);
        });
    };

    // refreshes cards
    const refresh = () => {
        forceUpdate();
    };

    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    // handles opening of add popup
    const handleOpenAdd = () => {
        setOpenAdd(true);
    };

    // handles closing of add popup
    const handleCloseAdd = () => {
        setOpenAdd(false);
    };

    const handleCreateRental = () =>{ 
        processNewRental();
        let url = `${bURL}`;
        axios.post(url, {
            CarID: carID,
            CustomerID: customerID,
            EmployeeID: employeeID,
            BranchID: branchID,
            DateFrom: dateFrom,
            DateTo: dateTo,
            TotalCost: totalCost,
            LicensePlate: licensePlate,
            GoldMember: goldmember
        }).then(function (response) {
            console.log(response);
        }).catch(function (error) {
            console.log(error);
        });
        setCarID("");
        setCustomerID("");
        setEmployeeID("");
        setBranchID("");
        setDateFrom("");
        setDateTo("");
        setTotalCost("");
        setLicensePlate("");
        setGoldmember("");

        setAddRentalButtonStatus(false);
    }

    // handles opening of edit snackbar
    const handleAddSnackbarClick = () => {
        setOpenAddSnackbar(true);
    };

    // handles closing of edit snackbar
    const handleAddSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
        return;
        }
        setOpenAddSnackbar(false);
    };

    const carChange = async (event: SelectChangeEvent) => {
        await setCarID(event.target.value as string);
    }
    const branchChange = async (event: SelectChangeEvent) => {
        await setBranchID(event.target.value as string);

        var bID = event.target.value as string;

        var tmp:any[] = new Array(allCars.length);
        allCars.map((car) => {
            if (car.BranchID === bID){
                tmp.push(car);
            }
        })
        await setCarsRefined(tmp);

        var tmp2:any[] = new Array(allEmployees.length);

        allEmployees.map((employee) =>{
            if (employee.BranchNumber === bID){
                tmp2.push(employee)
            }
        })
        await setEmployesRefined(tmp2);
    }
    const employeeChange = async (event: SelectChangeEvent) => {
        await setEmployeeID(event.target.value as string);
    }
    const customerChange = async (event: SelectChangeEvent) => {
        await setCustomerID(event.target.value as string);

        var ind: number = +event.target.value;
        var cust = allCustomers.at(ind);
        var gm = cust.GoldMember;
        console.log("Goldmember? ", gm);
        await setGoldmember(gm);
    }

    const fetchCarType = async () => {
        var carIDNum: number = +carID;

        var type = allCars.at(carIDNum).TypeID;

        await axios.get(`${window.location.origin.toString()}/api/cartype/${type}`).then((response) => {
            setCarType(response.data);
        });

    }

    const processNewRental = async () => {
        fetchCarType();

        var carIDNum: number = +carID;

        var dCost: number = +carType.DailyCost;

        var xx = new Date(dateFrom);
        var xy = new Date(dateTo);

        var diff = Math.abs(xy.getTime() - xx.getTime());
        var diffDays = Math.ceil(diff / (1000 * 3600 * 24));

        var cost = (diffDays * dCost).toFixed(2);

        setTotalCost(cost);
        setAddRentalButtonStatus(true);
        setLicensePlate(allCars.at(carIDNum).LicencePlate);
    }

    const getRandomeValue = () => {
        var tmp:Date = new Date();
        var val = tmp.valueOf();
        return val
    }

    const flushEmployeChange = () =>{
        employeesRefined.map((item) => {
            item.pop();
        })
    }

    const flushCarChange = () => {
        carsRefined.map((item) => {
            item.pop();
        })
    }

    return (
        <div>
            <div>
                <div>
                    <h1>Rentals</h1>
                </div>
                <Box justifyContent="flex-end" sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        '& > :not(style)': {
                            p: 2,
                            mr: "5%"
                        },
                    }}>
                    <Button variant="contained" sx={{
                        color: "#1B1B1B",
                        backgroundColor: "#87C00D",
                        '&:hover': {
                            backgroundColor: '#87C00D',
                          }}}
                          onClick={handleOpenAdd}>
                         <Typography>
                            <Box sx={{ fontWeight: 'bold'}}>
                                Add New Rental
                            </Box>
                        </Typography></Button>
                </Box>
                
            </div>
            <div>
                <Dialog open={openAdd} onClose={handleClose} style={{ textAlign: "center" }}>
                    <DialogTitle >Add Rental</DialogTitle>
                    <DialogContent>
                        <Box
                        component="form"
                        sx={{
                            '& .MuiTextField-root': { m: 1, width: '25ch' },
                        }}
                        noValidate
                        autoComplete="off">
                        <div>
                            <Grid container sx={{ flexGrow: 1, maxWidth: 600}}>
                                <Grid item xs={12}>
                                    <Grid container justifyContent={"center"} spacing={2}>
                                        <Grid item>
                                            <Box sx={{minWidth: 250, maxWidth: 200}}>
                                                <FormControl fullWidth>
                                                    <InputLabel>Select Branch</InputLabel>
                                                    <Select
                                                        labelId="branchID-selector"
                                                        id="branchID-select"
                                                        value={branchID}
                                                        label="Select branchID"
                                                        onChange={branchChange}>
                                                        {
                                                            allBranchs?.length > 0
                                                            ? (
                                                                allBranchs.map((branch) => (
                                                                    <MenuItem value={branch.BranchID} key={`${branch.City}:${getRandomeValue()}`}>
                                                                        {branch.City} {branch.Province}
                                                                    </MenuItem>
                                                                )))
                                                            : (<MenuItem>No Branches Found</MenuItem>)
                                                        } 
                                                    </Select>
                                                </FormControl>
                                            </Box>
                                        </Grid>
                                        <Grid item>
                                            <Box sx={{minWidth: 250, maxWidth: 200}}>
                                                <FormControl fullWidth>
                                                    <InputLabel>Select Car</InputLabel>
                                                    <Select
                                                        labelId="carID-selector"
                                                        id="carID-select"
                                                        value={carID}
                                                        label="Select carID"
                                                        onChange={carChange}>
                                                        {
                                                            carsRefined?.length > 0
                                                            ? (
                                                                carsRefined.map((car) => (
                                                                    <MenuItem 
                                                                        value={car.CarID} 
                                                                        key={`${car.Mileage}:${getRandomeValue()}`}>
                                                                        {car.Manufacturer} {car.Model}
                                                                    </MenuItem>
                                                                )))
                                                            : (<MenuItem>Select Branch First</MenuItem>)
                                                        } 
                                                    </Select>
                                                </FormControl>
                                            </Box>
                                        </Grid>
                                        <Grid item>
                                            <Box sx={{minWidth: 250, maxWidth: 200}}>
                                                <FormControl fullWidth>
                                                    <InputLabel>Select Customer</InputLabel>
                                                    <Select
                                                        labelId="customerID-selector"
                                                        id="customerID-select"
                                                        value={customerID}
                                                        label="Select customerID"
                                                        onChange={customerChange}
                                                        >
                                                        {
                                                            allCustomers?.length > 0
                                                            ? (
                                                                allCustomers.map((customer) => (
                                                                    <MenuItem value={customer.CustomerID} key={`${customer.Email}:${getRandomeValue()}`}>
                                                                        {customer.FirstName} {customer.LastName}
                                                                    </MenuItem>
                                                                )))
                                                            : (<MenuItem>No Customers Found</MenuItem>)
                                                        } 
                                                    </Select>
                                                </FormControl>
                                            </Box>
                                        </Grid>
                                        <Grid item>
                                            <Box sx={{minWidth: 250, maxWidth: 200}}>
                                                <FormControl fullWidth>
                                                    <InputLabel>Select Employee</InputLabel>
                                                    <Select
                                                        required
                                                        labelId="employeeID-selector"
                                                        id="employeeID-select"
                                                        value={employeeID}
                                                        label="Select employeeID"
                                                        onChange={employeeChange}>
                                                        {
                                                            employeesRefined?.length > 0
                                                            ? (
                                                                employeesRefined.map((employee) => (
                                                                    <MenuItem 
                                                                        value={employee.EmployeeID} 
                                                                        key={`${employee.Email}:${getRandomeValue()}`}>
                                                                        {employee.FirstName} {employee.LastName}
                                                                    </MenuItem>
                                                                )))
                                                            : (<MenuItem>Select Branch First</MenuItem>)
                                                        } 
                                                    </Select>
                                                </FormControl>
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                            
                            
                            <TextField
                            required
                            id="province-field"
                            label="DateFrom"
                            variant="filled"
                            type="date"
                            InputLabelProps={{
                                shrink:true,
                            }}
                            onChange={(e) => setDateFrom(e.target.value)}
                            />
                            <TextField
                            required
                            id="city-field"
                            label="DateTo"
                            variant="filled"
                            type="date"
                            InputLabelProps={{
                                shrink:true,
                            }}

                            onChange={(e) => setDateTo(e.target.value)}

                            />
                        </div>
                        </Box>
                    </DialogContent>                    
                    <DialogActions>
                        <Button onClick={handleCloseAdd}>Cancel</Button>
                        <Button
                            onClick={processNewRental} 
                            >Process</Button>
                        {addRentalButtonStatus ? <Button 
                        onClick={() => {
                        handleCloseAdd();
                        handleCreateRental();
                        refresh();
                        handleAddSnackbarClick();
                        }}>Add</Button> : <Button disabled>Add</Button>}
                    </DialogActions>
                </Dialog>
            </div>

            <div>
                <Box 
                    justifyContent="center" 
                    sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        '& > :not(style)': {
                            p: 2,
                            m: 2,
                            width: '90%',
                            height: '90%',
                            bgcolor: '#C1C1C1'
                        },
                    }}>
                    <Paper>
                        <div><h2>List of Rentals</h2></div>
                        {
                        rentalData?.length > 0
                            ? (
                                <div className='container'>
                                    {rentalData.map((r) =>(
                                        <div className='customerClass' key={r.RentalID}>
                                            <RentalCard rental={r} refresh={refresh}/>
                                        </div>
                                    ))}
                                </div>

                            ) : (
                                <div className='empty'>
                                    <h3> No Rentals Found :(</h3>
                                </div>
                            )
                        } 
                    </Paper>
                </Box>                
            </div>
            <div className='snackbar'>
                <Stack spacing={2} sx={{ width: '100%' }}>
                    {/* Add snack bar*/}
                    <Snackbar open={openAddSnackbar} autoHideDuration={3000} onClose={handleAddSnackbarClose}>
                        <Alert onClose={handleAddSnackbarClose} severity="success" sx={{ width: '100%' }}>
                            Rental "{`${carID}`}" has been sucessfully added!
                        </Alert>
                    </Snackbar>
                </Stack>
            </div>
        </div>
    );
}