export default function BoxSx() {
  return (
    <h1>Contact page</h1>
  );
}