import { useState, useEffect, useReducer } from 'react';
import CustomerCard from './../components/CustomerCard'
import FormProps from './../components/FormProps'
import Card from '@mui/material/Card'
import axios from 'axios';
import { Box, Button, Checkbox, Dialog, DialogActions, DialogContent, DialogTitle, FormControlLabel, FormGroup, Paper, Snackbar, TextField, Typography } from '@mui/material';
import { Add } from '@mui/icons-material';
import MuiAlert, { AlertProps } from '@mui/material/Alert';
import React from 'react';
import Stack from '@mui/material/Stack';

const bURL = `${window.location.origin.toString()}/api/customer/`

// alert for snackbar
const Alert = React.forwardRef<HTMLDivElement, AlertProps>(function Alert(
    props,
    ref,
  ) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
  });

export default function Customers() {
    const [cdata, setCdata] = useState<any[]>([]);
    const [update, forceUpdate] = useReducer(x => x + 1, 0);
    const [openAdd, setOpenAdd] = useState(false);
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

    const [openAddSnackbar, setOpenAddSnackbar] = useState(false);
    
    const [fName, setFName] = useState("");
    const [lName, setLName] = useState("");
    const [license, setLicense] = useState("");
    const [email, setEmail] = useState("");
    const [dob, setDob] = useState("");
    const [goldMember, setGoldMember] = useState(false);
    const [city, setCity] = useState("");
    const [province, setProvince] = useState("");
    const [postal, setPostal] = useState("");
    const [streetNum, setStreetNum] = useState("");
    const [streetName, setStreetName] = useState("");
    const [unitNum, setUnitNum] = useState("");
    
    useEffect(() => {
        axios.get(bURL).then((response) => {
            setCdata(response.data);
        });
    }, [update]);

    const updateCustomers = () => {
        axios.get(`${window.location.origin.toString()}/api/customer/`).then((response) => {
            setCdata(response.data);
        });
    };

    // refreshes cards
    const refresh = () => {
        forceUpdate();
    };

    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    // handles opening of add popup
    const handleOpenAdd = () => {
        setOpenAdd(true);
    };

    // handles closing of add popup
    const handleCloseAdd = () => {
        setOpenAdd(false);
    };

    const handleCreateCust = () =>{ 
        let url = `${bURL}`;
        axios.post(url, {
          FirstName: fName,
          LastName: lName,
          DriversLicense: license,
          Email: email,
          DOB: dob,
          GoldMember: goldMember,
          Province: province,
          City: city,
          PostalCode: postal,
          StreetNumber: streetNum,
          StreetName: streetName,
          UnitNumber: unitNum
        }).then(function (response) {
          console.log(response);
        }).catch(function (error) {
          console.log(error);
        });
      }

    // handles opening of edit snackbar
    const handleAddSnackbarClick = () => {
        setOpenAddSnackbar(true);
    };

    // handles closing of edit snackbar
    const handleAddSnackbarClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
        return;
        }
        setOpenAddSnackbar(false);
    };

    return (
        <div>
            <div>
                <h1>Customers</h1>
                <Box justifyContent="flex-end" sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        '& > :not(style)': {
                            p: 2,
                            mr: "5%"
                        },
                    }}>
                    <Button variant="contained" sx={{
                        color: "#1B1B1B",
                        backgroundColor: "#87C00D",
                        '&:hover': { backgroundColor: '#87C00D', 
                        }}} 
                        onClick={handleOpenAdd}>
                        <Typography>
                            <Box sx={{ fontWeight: 'bold'}}>
                                Add New Customer
                            </Box>
                        </Typography>
                    </Button>
                </Box>
                
            </div>
            <div>
                <Dialog open={openAdd} onClose={handleClose} style={{ textAlign: "center" }}>
                    <DialogTitle >Add Customer</DialogTitle>
                    <DialogContent>
                        <Box
                        component="form"
                        sx={{
                            '& .MuiTextField-root': { m: 1, width: '25ch' },
                        }}
                        noValidate
                        autoComplete="off">
                        <div>
                            <TextField
                            required
                            id="fname-field"
                            label="FirstName"
                            multiline
                            variant="filled"
                            onChange={(e) => setFName(e.target.value)}
                            />
                            <TextField
                            required
                            id="lname-field"
                            label="LastName"
                            variant="filled"

                            onChange={(e) => setLName(e.target.value)}
                            />
                            <TextField
                            required
                            id="license-field"
                            label="DriversLicense"
                            variant="filled"

                            onChange={(e) => setLicense(e.target.value)}
                            />
                            <TextField
                            required
                            id="email-field"
                            label="Email"
                            variant="filled"

                            onChange={(e) => setEmail(e.target.value)}
                            />
                            <TextField
                            required
                            id="dob-field"
                            label="Date of Birth"
                            variant="filled"
                            type="date"
                            InputLabelProps={{
                                shrink: true,
                            }}
                            
                            onChange={(e) => setDob(e.target.value)}
                            />
                            <div className="checkbox">
                            <FormGroup >
                                <FormControlLabel control={
                                <Checkbox
                                    id="goldmember-value"
                                    value={goldMember}
                                    defaultChecked={false}
                                    onChange={(e) => setGoldMember(e.target.checked)}
                                />
                                } label="GoldMember?" />
                            </FormGroup>
                            </div>
                            <TextField
                            required
                            id="province-field"
                            label="Province"
                            variant="filled"

                            onChange={(e) => setProvince(e.target.value)}
                            />
                            <TextField
                            required
                            id="city-field"
                            label="City"
                            variant="filled"

                            onChange={(e) => setCity(e.target.value)}

                            />
                            <TextField
                            required
                            id="postalcode-field"
                            label="Postal Code"
                            variant="filled"

                            onChange={(e) => setPostal(e.target.value)}
                            />
                            <TextField
                            required
                            id="streetnum-field"
                            label="Street Number"
                            variant="filled"

                            onChange={(e) => setStreetNum(e.target.value)}
                            />
                            <TextField
                            required
                            id="streename-field"
                            label="Street Name"
                            variant="filled"

                            onChange={(e) => setStreetName(e.target.value)}
                            />
                            <TextField
                            required
                            id="unitnum-field"
                            label="Unit Number"
                            variant="filled"

                            onChange={(e) => setUnitNum(e.target.value)}
                            />
                        </div>
                        </Box>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleCloseAdd}>Cancel</Button>
                        <Button onClick={() => {
                        handleCloseAdd();
                        handleCreateCust();
                        refresh();
                        handleAddSnackbarClick();
                        }}>Add</Button>
                    </DialogActions>
                </Dialog>
            </div>

            <div>
                <Box 
                    justifyContent="center" 
                    sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        '& > :not(style)': {
                            p: 2,
                            m: 2,
                            width: '90%',
                            height: '90%',
                            bgcolor: '#C1C1C1'
                        },
                    }}>
                    <Paper>
                    <h2>List of Customers</h2>
                        {
                        cdata?.length > 0
                            ? (
                                <div className="container">
                                    {cdata.map((individual) => (
                                        <div className="customerClass">
                                            <CustomerCard customer={individual} refresh={refresh} />
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="empty">
                                    <h3>No Customers Found :(</h3>
                                </div>
                            )
                        }
                        
                    </Paper>
                </Box>
                
            </div>
            <div className='snackbar'>
                <Stack spacing={2} sx={{ width: '100%' }}>
                    {/* Add snack bar*/}
                    <Snackbar open={openAddSnackbar} autoHideDuration={3000} onClose={handleAddSnackbarClose}>
                        <Alert onClose={handleAddSnackbarClose} severity="success" sx={{ width: '100%' }}>
                            Customer "{`${fName} ${lName}`}" has been sucessfully added!
                        </Alert>
                    </Snackbar>
                </Stack>
            </div>
        </div>
    );
}