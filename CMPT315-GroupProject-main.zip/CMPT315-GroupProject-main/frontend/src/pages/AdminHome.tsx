import './AdminHome.css';

export default function AdminHome() {
    const getGreeting = () => {
        let time = new Date().toLocaleTimeString().split(' ');

        if (time[1] === "AM") {
            return 'Good morning';
        } else {
            return 'Good afternoon';
        }
    }

    return (
        <div className="admin-container">

            <div className='header' >
                <h1 className='admin-header-text'>{`${getGreeting()}, Randy!`}</h1>
                <h1 className="behind-text">{`${getGreeting().toUpperCase()}`}</h1>
            </div>

            <div className='coffee-container'>
                <div className="top">
                    <div className="btn btn1"></div>
                    <div className="btn btn2"></div>
                    <div className="timer"></div>
                    <div className="side-btn"></div>
                    <div className="coffee-text">coffee</div>
                </div>
                <div className="mid">
                    <div className="coffee-box"></div>
                    <div className="cup"></div>
                    <div className="coffee"></div>
                    <div className="steam steam1"></div>
                    <div className="steam steam2"></div>
                    <div className="steam steam3"></div>
                    <div className="steam steam4"></div>
                </div>
                <div className="bottom">
                    <div className="base"></div>
                    <div className="stand"></div>
                </div>
            </div>
        </div>
    );
}