#!/usr/bin/python3
import json
import requests

CUSTDATA_AMOUNT = 5
BRANCHDATA_AMOUNT = 50
CARTYPE_AMOUNT = 50
CARDATA_AMOUNT = 50

LIMITS = [CARTYPE_AMOUNT, BRANCHDATA_AMOUNT, CARDATA_AMOUNT]

FSALL = [
	["CarTypeData.json", "cartype/", 50],
	["BranchData.json", "branch/", 50], 
	["315_CustomerData.json", "customer/", 50],
	["315_EmployeeData.json", "employee/", 100],
	["315_CarData.json", "car/", 50],
	]


for i in range(len(FSALL)):
	

	with open(FSALL[i][0], "r") as myFile:
		data = myFile.readlines()

		for j in range(FSALL[i][2]):

			payload = json.loads(data[j][:-1])
			r = requests.post("http://localhost:3000/api/"+FSALL[i][1], json=payload)

			print(FSALL[i][0]+", STATUS: "+str(r.status_code))



